//Enable strict mode
"use strict";

//create room layouts
const roomTemps = {
  n:[
    [
      [
        ["ww","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["cl","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","cr"]
      ],
      ()=>{
        let ret = [];
        //enemies
        let es = Math.floor(Math.random()*10);
        for(let i=0;i<es;i++){
          let x = Math.floor(Math.random()*(Constants.sizes.roomSize.x-2)+1)*Constants.sizes.tileSize.x;
          let y = Math.floor(Math.random()*(Constants.sizes.roomSize.y-2)+1)*Constants.sizes.tileSize.y;
          if(Math.random() > 0.9){
            ret.push(new RangedEnemy(x,y));
          } else {
            ret.push(new BasicEnemy(x,y));
          }
        }
        //rocks
        let amount = Math.floor(Math.random() * 20);
        for(let i=0;i<amount;i++){
          ret.push(new Rock(
            (Math.floor(Math.random()*27)+2)*Constants.sizes.tileSize.x,
            (Math.floor(Math.random()*13)+2)*Constants.sizes.tileSize.y
          ));
        }
        return ret;
      }
    ],
    [
      [
        ["ww","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","we"],
        ["ww","pt","pt","pt","pt","pt","pt","pt","pt","pt","pt","pt","pt","pt","pt","g", "pt","pt","pt","pt","pt","pt","pt","pt","pt","pt","pt","pt","pt","pt","we"],
        ["ww","p", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "p", "we"],
        ["ww","p", "g", "g", "g", "g", "pt","pt","pt","pt","pt","pt","pt","pt","pt","g", "pt","pt","pt","pt","pt","pt","pt","pt","pt","g", "g", "g", "g", "p", "we"],
        ["ww","p", "g", "g", "g", "g", "p", "p", "p", "p", "p", "p", "p", "p", "p", "g", "p", "p", "p", "p", "p", "p", "p", "p", "p", "g", "g", "g", "g", "p", "we"],
        ["ww","p", "g", "g", "g", "g", "p", "p", "p", "p", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "p", "p", "p", "p", "g", "g", "g", "g", "p", "we"],
        ["ww","p", "g", "pt","pt","pt","p", "p", "p", "p", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "p", "p", "p", "p", "pt","pt","pt","g", "p", "we"],
        ["ww","p", "g", "p", "p", "p", "p", "p", "p", "p", "g", "g", "g", "g", "pt","pt","pt","g", "g", "g", "g", "p", "p", "p", "p", "p", "p", "p", "g", "p", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "p", "p", "p", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","pt","g", "pt","pt","pt","pt","pt","pt","pt","g", "g", "g", "g", "p", "p", "p", "g", "g", "g", "g", "pt","pt","pt","pt","pt","pt","pt","g", "pt","we"],
        ["ww","p", "g", "p", "p", "p", "p", "p", "p", "p", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "p", "p", "p", "p", "p", "p", "p", "g", "p", "we"],
        ["ww","p", "g", "g", "g", "g", "p", "p", "p", "p", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "p", "p", "p", "p", "g", "g", "g", "g", "p", "we"],
        ["ww","p", "g", "g", "g", "g", "p", "p", "p", "p", "pt","pt","pt","pt","pt","g", "pt","pt","pt","pt","pt","p", "p", "p", "p", "g", "g", "g", "g", "p", "we"],
        ["ww","p", "g", "g", "g", "g", "p", "p", "p", "p", "p", "p", "p", "p", "p", "g", "p", "p", "p", "p", "p", "p", "p", "p", "p", "g", "g", "g", "g", "p", "we"],
        ["ww","p", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "p", "we"],
        ["ww","p", "pt","pt","pt","pt","pt","pt","pt","pt","pt","pt","pt","pt","pt","g", "pt","pt","pt","pt","pt","pt","pt","pt","pt","pt","pt","pt","pt","p", "we"],
        ["cl","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","cr"]
      ],
      ()=>{return [
        new BasicEnemy(4*Constants.sizes.tileSize.x,3*Constants.sizes.tileSize.y),
        new BasicEnemy(24*Constants.sizes.tileSize.x,3*Constants.sizes.tileSize.y),
        new BasicEnemy(4*Constants.sizes.tileSize.x,11*Constants.sizes.tileSize.y),
        new BasicEnemy(24*Constants.sizes.tileSize.x,11*Constants.sizes.tileSize.y),
        new RangedEnemy(15*Constants.sizes.tileSize.x,8*Constants.sizes.tileSize.y),
        new RangedEnemy(8*Constants.sizes.tileSize.x,10*Constants.sizes.tileSize.y),
        new RangedEnemy(22*Constants.sizes.tileSize.x,10*Constants.sizes.tileSize.y),
        new RangedEnemy(8*Constants.sizes.tileSize.x,6*Constants.sizes.tileSize.y),
        new RangedEnemy(22*Constants.sizes.tileSize.x,6*Constants.sizes.tileSize.y)
      ]}
    ],
    [
      [
        ["ww", "wn", "wn", "wn", "wn", "wn", "we", "ww", "wn", "wn", "wn", "wn", "wn", "wn", "wn", "wn", "wn", "wn", "wn", "wn", "wn", "wn", "wn", "we", "ww", "wn", "wn", "wn", "wn", "wn", "we"],
        ["ww", "g",  "g",  "g",  "g",  "g",  "we", "ww", "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "we", "ww", "g",  "g",  "g",  "g",  "g",  "we"],
        ["ww", "g",  "g",  "g",  "g",  "g",  "we", "ww", "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "we", "ww", "g",  "g",  "g",  "g",  "g",  "we"],
        ["ww", "g",  "g",  "g",  "g",  "g",  "we", "ww", "g",  "g",  "g",  "deu","dwu","dwu","dwu","dwu","dwu","dwu","dwu","dwu","g",  "g",  "g",  "we", "ww", "g",  "g",  "g",  "g",  "g",  "we"],
        ["ww", "g",  "g",  "g",  "g",  "g",  "we", "ww", "g",  "g",  "g",  "we", "b",  "b",  "b",  "b",  "b",  "b",  "b",  "ww", "g",  "g",  "g",  "we", "ww", "g",  "g",  "g",  "g",  "g",  "we"],
        ["cl", "ws", "ws", "dv", "ws", "ws", "cr", "ww", "g",  "g",  "g",  "we", "ww", "wn", "wn", "wn", "wn", "wn", "we", "ww", "g",  "g",  "g",  "we", "cl", "ws", "ws", "dv", "ws", "ws", "cr"],
        ["ww", "wn", "wn", "dv", "wn", "wn", "wn", "wn", "g",  "g",  "g",  "we", "ww", "g",  "g",  "g",  "g",  "g",  "we", "ww", "g",  "g",  "g",  "wn", "wn", "wn", "wn", "dv", "wn", "wn", "we"],
        ["ww", "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "we", "ww", "g",  "g",  "g",  "g",  "g",  "we", "ww", "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "we"],
        ["ww", "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "we", "ww", "g",  "g",  "g",  "g",  "g",  "we", "ww", "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "we"],
        ["ww", "deu","deu","g",  "deu","deu","deu","dwu","g",  "g",  "g",  "we", "ww", "g",  "g",  "g",  "g",  "g",  "we", "ww", "g",  "g",  "g",  "deu","dwu","dwu","dwu","g",  "dwu","dwu","we"],
        ["b",  "b",  "b",  "dv", "b",  "b",  "b",  "ww", "g",  "g",  "g",  "we", "ww", "g",  "g",  "g",  "g",  "g",  "we", "ww", "g",  "g",  "g",  "we", "b",  "b",  "b",  "dv", "b",  "b",  "b" ],
        ["ww", "wn", "wn", "dv", "wn", "wn", "we", "ww", "g",  "g",  "g",  "we", "cl", "ws", "ws", "dv", "ws", "ws", "cr", "ww", "g",  "g",  "g",  "we", "ww", "wn", "wn", "dv", "wn", "wn", "we"],
        ["ww", "g",  "g",  "g",  "g",  "g",  "we", "ww", "g",  "g",  "g",  "wn", "wn", "wn", "wn", "dv", "wn", "wn", "wn", "wn", "g",  "g",  "g",  "we", "ww", "g",  "g",  "g",  "g",  "g",  "we"],
        ["ww", "g",  "g",  "g",  "g",  "g",  "we", "ww", "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "we", "ww", "g",  "g",  "g",  "g",  "g",  "we"],
        ["ww", "g",  "g",  "g",  "g",  "g",  "we", "ww", "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "we", "ww", "g",  "g",  "g",  "g",  "g",  "we"],
        ["ww", "g",  "g",  "g",  "g",  "g",  "we", "ww", "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "we", "ww", "g",  "g",  "g",  "g",  "g",  "we"],
        ["cl", "ws", "ws", "ws", "ws", "ws", "cr", "cl", "ws", "ws", "ws", "ws", "ws", "ws", "ws", "ws", "ws", "ws", "ws", "ws", "ws", "ws", "ws", "cr", "cl", "ws", "ws", "ws", "ws", "ws", "cr"]
      ],
      ()=>{
        //find number of chests
        let numChests = Array.randElem(
          [5,4,4,4].concat(
          buildRand(3,9)).concat(
          buildRand(2,27)).concat(
          buildRand(1,81)).concat(
          buildRand(0,243))
        );
        //find chest locations
        let locs = new Array(5);
        locs.fill(false);
        locs.fill(true,0,numChests);
        locs.sort((a,b)=>{return Math.random()-0.5;});
        let spots = {};
        for(let spot of ["nw","ne","sw","se","c","g"]){
          spots[spot] = {chest:locs.pop()};
        }
        //add doors
        for(let spot of Object.keys(spots)){
          spots[spot].door = Math.random()<0.1+(spots[spot].chest?0.8:0);
        }
        //create sprites
        let ret = [
          new BasicEnemy(
            2*Constants.sizes.tileSize.x,
            2*Constants.sizes.tileSize.y
          ),
          new BasicEnemy(
            (Constants.sizes.roomSize.x-2)*Constants.sizes.tileSize.x,
            2*Constants.sizes.tileSize.y
          ),
          new BasicEnemy(
            2*Constants.sizes.tileSize.x,
            (Constants.sizes.roomSize.y-2)*Constants.sizes.tileSize.y
          ),
          new BasicEnemy(
            (Constants.sizes.roomSize.x-2)*Constants.sizes.tileSize.x,
            (Constants.sizes.roomSize.y-2)*Constants.sizes.tileSize.y
          )
        ];
        //chests
        for(let spot of Object.keys(spots)){
          //chest
          if(spots[spot].chest){
            let args = {
              x:{
                nw:Constants.sizes.tileSize.x*3,
                ne:Constants.sizes.tileSize.x*27,
                sw:Constants.sizes.tileSize.x*3,
                se:Constants.sizes.tileSize.x*27,
                c:Constants.sizes.tileSize.x*15
              }[spot],
              y:{
                nw:Constants.sizes.tileSize.y*2,
                ne:Constants.sizes.tileSize.y*2,
                sw:Constants.sizes.tileSize.y*14,
                se:Constants.sizes.tileSize.y*14,
                c:Constants.sizes.tileSize.y*8
              }[spot],
              type:Array.randElem([
                "gold","item","item"
              ])
            };
            if(Math.random()<0.1*diff[area]){
              ret.push(new ChestEnemy(
                args.x,args.y,args.type
              ));
            } else {
              ret.push(new Chest(
                args.x,args.y,args.type
              ));
            }
          }
          //door
          if(spots[spot].door){
            ret.push(
              new LockedDoor(
                {
                  nw:Constants.sizes.tileSize.x*3,
                  ne:Constants.sizes.tileSize.x*27,
                  sw:Constants.sizes.tileSize.x*3,
                  se:Constants.sizes.tileSize.x*27,
                  c:Constants.sizes.tileSize.x*15
                }[spot],
                {
                  nw:Constants.sizes.tileSize.y*6,
                  ne:Constants.sizes.tileSize.y*6,
                  sw:Constants.sizes.tileSize.y*10,
                  se:Constants.sizes.tileSize.y*10,
                  c:Constants.sizes.tileSize.y*12
                }[spot]
              )
            );
          }
        }
        return ret;
      }
    ],
    [
      [
        ["ww","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "pt","pt","pt","pt","pt","pt","pt","pt","pt","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "pt","pt","pt","p", "p", "p", "p", "p", "p", "p", "p", "p", "pt","pt","pt","g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "pt","pt","p", "p", "p", "p", "p", "p", "p", "p", "p", "p", "p", "p", "p", "p", "p", "pt","pt","g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g","g","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g","g","g", "g", "g", "we"],
        ["ww","g", "g", "g","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g","g", "g", "we"],
        ["ww","g", "g", "g", "pt", "pt", "pt", "pt", "pt", "pt", "pt", "pt", "pt", "pt", "pt", "pt", "pt", "pt", "pt", "pt", "pt", "pt", "pt", "pt", "pt", "pt", "pt", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "p", "p", "p", "p", "p", "p", "p", "p", "p", "p", "p", "p", "p", "p", "p", "p", "p", "p", "p", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "p", "p", "p", "p", "p", "p", "p", "p", "p", "p", "p", "p", "p", "p", "p", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "p", "p", "p", "p", "p", "p", "p", "p", "p", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["cl","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","cr"]
      ],
      ()=>{return [
        new BasicEnemy(
          4*Constants.sizes.tileSize.x,
          3*Constants.sizes.tileSize.y
        ),
        new BasicEnemy(
          24*Constants.sizes.tileSize.x,
          3*Constants.sizes.tileSize.y
        ),
        new BasicEnemy(
          4*Constants.sizes.tileSize.x,
          11*Constants.sizes.tileSize.y
        ),
        new BasicEnemy(
          24*Constants.sizes.tileSize.x,
          11*Constants.sizes.tileSize.y
        ),
        new RangedEnemy(8*Constants.sizes.tileSize.x,10*Constants.sizes.tileSize.y),
        new RangedEnemy(22*Constants.sizes.tileSize.x,10*Constants.sizes.tileSize.y),
        new RangedEnemy(8*Constants.sizes.tileSize.x,6*Constants.sizes.tileSize.y),
        new RangedEnemy(22*Constants.sizes.tileSize.x,6*Constants.sizes.tileSize.y)
      ]}
    ],
  ],
  s: [
    [
      [
        ["ww","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["cl","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","cr"]
      ],
      ()=>{
        //generate shop layout
        //0 - nothing
        //1 - item
        //2 - basic item
        //3 - healing item
        let layout = (
          [3,3,3,3,3,3,3,3,3,2,2,2,2,2,2,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0]
          .sort((a,b)=>{return Math.random()-0.5})
          ).slice(0,9);
        //create sprites
        let locs = {
          0:{
            x:(Constants.sizes.roomTSize.x-Constants.sizes.tileSize.x)/2,
            y:(Constants.sizes.roomTSize.y-Constants.sizes.tileSize.y)/2
          },
          1:{
            x:(Constants.sizes.roomTSize.x-Constants.sizes.tileSize.x)/4,
            y:(Constants.sizes.roomTSize.y-Constants.sizes.tileSize.y)/2
          },
          2:{
            x:(Constants.sizes.roomTSize.x-Constants.sizes.tileSize.x)*0.75,
            y:(Constants.sizes.roomTSize.y-Constants.sizes.tileSize.y)/2
          },
          3:{
            x:(Constants.sizes.roomTSize.x-Constants.sizes.tileSize.x)/2,
            y:(Constants.sizes.roomTSize.y-Constants.sizes.tileSize.y)*0.75
          },
          4:{
            x:(Constants.sizes.roomTSize.x-Constants.sizes.tileSize.x)/4,
            y:(Constants.sizes.roomTSize.y-Constants.sizes.tileSize.y)*0.75
          },
          5:{
            x:(Constants.sizes.roomTSize.x-Constants.sizes.tileSize.x)*0.75,
            y:(Constants.sizes.roomTSize.y-Constants.sizes.tileSize.y)*0.75
          },
          6:{
            x:(Constants.sizes.roomTSize.x-Constants.sizes.tileSize.x)/2,
            y:(Constants.sizes.roomTSize.y-Constants.sizes.tileSize.y)/4
          },
          7:{
            x:(Constants.sizes.roomTSize.x-Constants.sizes.tileSize.x)/4,
            y:(Constants.sizes.roomTSize.y-Constants.sizes.tileSize.y)/4
          },
          8:{
            x:(Constants.sizes.roomTSize.x-Constants.sizes.tileSize.x)*0.75,
            y:(Constants.sizes.roomTSize.y-Constants.sizes.tileSize.y)/4
          }
        };
        let ret = [];
        for(let p=0;p<9;p++){
          let item = layout[p];
          if(item == 1){
            ret.push(
              new ShopItem(
                locs[p].x,
                locs[p].y
              )
            );
          }
          if(item == 2){
            ret.push(
              new ShopBasicItem(
                locs[p].x,
                locs[p].y
              )
            );
          }
          if(item == 3){
            ret.push(
              new ShopHealingItem(
                locs[p].x,
                locs[p].y
              )
            );
          }
        }
        //upper left
        ret.push(
          new Thing(32,32,"upper left",new Animator(
            anims.upperLeft,"idle"
          ))
        );
        //return
        return ret;
      }
    ]
  ],
  i: [
    [
      [
        ["ww","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["cl","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","cr"]
      ],
      ()=>{return [
        new Item(
          (Constants.sizes.roomTSize.x-Constants.sizes.tileSize.x)/2,
          (Constants.sizes.roomTSize.y-Constants.sizes.tileSize.y)/2
        )
      ]}
    ]
  ],
  b: [
    [
      [
        ["ww","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["cl","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","cr"]
      ],
      ()=>{
        if(Math.random()<0.5){
          return [
            new AdvancedEnemy(
              (Constants.sizes.roomTSize.x-Constants.sizes.tileSize.x)/2,
              (Constants.sizes.roomTSize.y-Constants.sizes.tileSize.y)/2,
              "normal",10
            )
          ];
        } else {
          return [
            new DividingEnemy(
              (Constants.sizes.roomTSize.x-Constants.sizes.tileSize.x)/2,
              (Constants.sizes.roomTSize.y-Constants.sizes.tileSize.y)/2,
              5,true,"normal",10
            )
          ];
        }
      }
    ]
  ],
  m: [
    [
      [
        ["ww","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["cl","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","cr"]
      ],
      ()=>{
        return [
          new AdvancedEnemy(
            (Constants.sizes.roomTSize.x-Constants.sizes.tileSize.x)/2,
            (Constants.sizes.roomTSize.y-Constants.sizes.tileSize.y)/2,
            "item",0
          )
        ];
      }
    ],
    [
      [
        ["ww","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["cl","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","cr"]
      ],
      ()=>{
        return [
          new DividingEnemy(
            (Constants.sizes.roomTSize.x-Constants.sizes.tileSize.x)/2,
            (Constants.sizes.roomTSize.y-Constants.sizes.tileSize.y)/2,
            5,true,"item",0
          )
        ];
      }
    ],
    /*[
      [
        ["ww", "wn", "wn", "wn", "wn", "wn", "wn", "wn", "wn", "wn", "wn", "wn", "wn", "wn", "wn", "wn", "wn", "wn", "wn", "wn", "wn", "wn", "wn", "wn", "wn", "wn", "wn", "wn", "wn", "wn", "we"],
        ["ww", "pt", "pt", "pt", "pt", "pt", "g",  "g",  "g",  "g",  "g",  "g",  "g",  "pt", "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "pt", "pt", "pt", "pt", "pt", "we"],
        ["ww", "p",  "p",  "p",  "p",  "p",  "g",  "pt", "g",  "pt", "pt", "pt", "g",  "p",  "g",  "pt", "g",  "pt", "pt", "pt", "g",  "pt", "g",  "pt", "g",  "p",  "p",  "p",  "p",  "p",  "we"],
        ["ww", "p",  "p",  "p",  "p",  "p",  "g",  "p",  "g",  "p",  "p",  "p",  "g",  "g",  "g",  "p",  "g",  "g",  "g",  "p",  "g",  "p",  "g",  "p",  "g",  "p",  "p",  "p",  "p",  "p",  "we"],
        ["ww", "p",  "p",  "p",  "p",  "p",  "g",  "p",  "g",  "p",  "p",  "p",  "pt", "pt", "g",  "p",  "pt", "pt", "g",  "p",  "g",  "p",  "g",  "p",  "g",  "p",  "p",  "p",  "p",  "p",  "we"],
        ["ww", "p",  "p",  "p",  "p",  "p",  "g",  "p",  "g",  "p",  "g",  "g",  "g",  "g",  "g",  "p",  "g",  "g",  "g",  "p",  "g",  "g",  "g",  "g",  "g",  "p",  "p",  "p",  "p",  "p",  "we"],
        ["ww", "p",  "p",  "p",  "p",  "p",  "g",  "p",  "pt", "p",  "g",  "pt", "pt", "pt", "g",  "p",  "g",  "pt", "g",  "p",  "g",  "pt", "pt", "pt", "pt", "p",  "p",  "p",  "p",  "p",  "we"],
        ["ww", "p",  "p",  "p",  "p",  "p",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "p",  "g",  "g",  "g",  "p",  "g",  "p",  "g",  "g",  "g",  "g",  "g",  "p",  "p",  "p",  "p",  "p",  "we"],
        ["ww", "g",  "g",  "g",  "g",  "g",  "pt", "pt", "g",  "pt", "g",  "pt", "g",  "p",  "g",  "pt", "pt", "p",  "g",  "p",  "pt", "pt", "pt", "pt", "g",  "g",  "g",  "g",  "g",  "g",  "we"],
        ["ww", "pt", "pt", "pt", "pt", "g",  "g",  "g",  "g",  "p",  "g",  "p",  "g",  "p",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "pt", "pt", "pt", "pt", "pt", "we"],
        ["ww", "p",  "p",  "p",  "p",  "pt", "pt", "pt", "pt", "p",  "g",  "p",  "g",  "p",  "g",  "pt", "pt", "pt", "g",  "pt", "pt", "pt", "g",  "p",  "p",  "p",  "p",  "p",  "p",  "p",  "we"],
        ["ww", "p",  "p",  "p",  "p",  "p",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "p",  "g",  "g",  "g",  "p",  "g",  "g",  "g",  "p",  "p",  "p",  "p",  "p",  "p",  "p",  "we"],
        ["ww", "p",  "p",  "p",  "p",  "p",  "g",  "pt", "g",  "pt", "pt", "pt", "pt", "pt", "g",  "p",  "g",  "pt", "pt", "p",  "g",  "pt", "g",  "p",  "p",  "p",  "p",  "p",  "p",  "p",  "we"],
        ["ww", "p",  "p",  "p",  "p",  "p",  "g",  "p",  "g",  "g",  "g",  "p",  "g",  "g",  "g",  "p",  "g",  "g",  "g",  "g",  "g",  "p",  "g",  "p",  "p",  "p",  "p",  "p",  "p",  "p",  "we"],
        ["ww", "p",  "p",  "p",  "p",  "p",  "g",  "p",  "pt", "pt", "g",  "p",  "g",  "pt", "pt", "p",  "g",  "pt", "pt", "pt", "pt", "p",  "g",  "p",  "p",  "p",  "p",  "p",  "p",  "p",  "we"],
        ["ww", "p",  "p",  "p",  "p",  "p",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "g",  "p",  "p",  "p",  "p",  "p",  "p",  "p",  "we"],
        ["cl", "ws", "ws", "ws", "ws", "ws", "ws", "ws", "ws", "ws", "ws", "ws", "ws", "ws", "ws", "ws", "ws", "ws", "ws", "ws", "ws", "ws", "ws", "ws", "ws", "ws", "ws", "ws", "ws", "ws", "cr"]
      ],
      ()=>{
        let ao = [
          {x:Constants.sizes.tileSize.x*6,y:Constants.sizes.tileSize.x*1},
          {x:Constants.sizes.tileSize.x*6,y:Constants.sizes.tileSize.x*15},
          {x:Constants.sizes.tileSize.x*24,y:Constants.sizes.tileSize.x*1},
          {x:Constants.sizes.tileSize.x*22,y:Constants.sizes.tileSize.x*15},
          {x:Constants.sizes.tileSize.x*16,y:Constants.sizes.tileSize.x*7}
        ];
        let a = Array.randElem(ao);
        return [new HiddenEnemy(a.x,a.y)];
      }
    ]*/
  ],
  f: [
    [
      [
        ["ww","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","wn","we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["ww","g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "g", "we"],
        ["cl","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","ws","cr"]
      ],
      ()=>{return []}
    ]
  ]
};
