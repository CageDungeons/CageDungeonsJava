//Enable strict mode
"use strict";

//constants
const Constants = {
  areas: [
    "Gates","Ash Flats","Bone Shore",
    "Cinder Wastes","Precipice","Fire Sea",
    "Shadow Caverns","Magma Pools",
    "The Castle"
  ],
  sizes: {
    roomSize:{x:31,y:17},
    tileSize:{x:32,y:32}
    //roomTSize
  },
  items: {
    steroids: class {
      constructor(added=false){
        this.name = "Steroids";
        this.text = "Power at a price";
        this.rarity = added?"Common":"Rare";
        this.maxHealth = {op:"x",val:0.9};
        this.mDam = {op:"x",val:1.1};
        this.priority = 2;
      }
      onGet(){
        for(let i=0;i<5;i++){
          heldItems.itemPool.push(new Constants.items.steroids(false));
        }
      }
    }
  },

  //Shhhh!
  cheats: {
    debug:{
      on:()=>{
        heldItems.addItem({
          name:"Debug Mode",
          maxHealth:{op:"+",val:500},
          mSpeed:{op:"+",val:100},
          mDam:{op:"+",val:100},
          mRange:{op:"+",val:25},
          rSpeed:{op:"+",val:10000},
          rDam:{op:"+",val:10000},
          rRange:{op:"+",val:32},
          special:"Floating",
          priority:1.5,
        });
        heldItems.addItem({
          special:"Lightning"
        });
      },
      fast:()=>{
        heldItems.addItem({
          special:"Fast Boss"
        });
      }
    },
    giveItem:()=>{
      let n = prompt("Item name:");
      heldItems.addItem(
        heldItems.itemPool.filter(i=>{
          return i.name==n;
        })[0]
      );
    }
  }
};

//constants that come from other constants
Constants.sizes.roomTSize = {
  x:Constants.sizes.roomSize.x*Constants.sizes.tileSize.x,
  y:Constants.sizes.roomSize.y*Constants.sizes.tileSize.y
};
