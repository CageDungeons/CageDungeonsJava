//Enable strict mode
"use strict";

//items
const heldItems = {
  items: [
    {
      name:"Total",
      text:"",
      rarity:"",
      speed:0,
      maxHealth:0,
      mSpeed:0,
      mDam:0,
      mRange:0,
      rSpeed:0,
      rDam:0,
      rRange:0,
      special:"",
      priority:0
    }
  ],
  basicItems: {
    coins: 0,
    keys: 0,
    bombs: 0
  },
  stats: {
    speed:0,
    maxHealth:0,
    mSpeed:0,
    mDam:0,
    mRange:0,
    rSpeed:0,
    rDam:0,
    rRange:0,
    special:[]
  },
  activeItem: {
    item:{
      name:"Pile of Dust",
      onActivate:()=>{},
      charges:0,
    },
    charges:0
  },
  itemPool: [
    //priorities: 1 - +/-, 2 - mults, 3 - ='s, 4 - effects
    //Ledgendary
    {
      name:"Multiplier",
      text:"More is always better, right?",
      rarity:"Ledgendary",
      speed:{op:"x",val:2},
      maxHealth:{op:"x",val:2},
      mSpeed:{op:"x",val:2},
      mDam:{op:"x",val:2},
      mRange:{op:"x",val:2},
      rSpeed:{op:"x",val:2},
      rDam:{op:"x",val:2},
      rRange:{op:"x",val:2},
      priority:2
    },
    {
      name:"Turmoil",
      text:"Randomize base stats every new room",
      rarity:"Ledgendary",
      special:"Random Stats",
      priority:4
    },
    {
      name:"Laser",
      text:"Shoot at the speed of light",
      rarity:"Ledgendary",
      rSpeed:{op:"+",val:"1000"},
      priority:1,
    },
    {
      name:"Minecraft",
      text:"Hit things across the room",
      rarity:"Ledgendary",
      mRange:{op:"+",val:30},
      priority:1
    },
    {
      name:"Glass Heart",
      text:"Fragile yet sharp",
      rarity:"Ledgendary",
      maxHealth:{op:"=",val:1},
      mDam:{op:"x",val:100},
      priority:3.5
    },
    {
      name:"Chestception!",
      text:"Chests in chests in...",
      rarity:"Ledgendary",
      special:"Chest Recursion",
      priority:4
    },
    //Very Rare
    {
      name:"Sanic Shoes",
      text:"Rediculous speed",
      rarity:"Very Rare",
      speed:{op:"+",val:30},
      priority:1,
    },
    {
      name:"Melee Mastery",
      text:"Become a master of the blade",
      rarity:"Very Rare",
      mSpeed:{op:"x",val:1.5},
      mDam:{op:"x",val:1.5},
      mRange:{op:"x",val:1.5},
      rSpeed:{op:"x",val:0.5},
      rDam:{op:"x",val:0.5},
      rRange:{op:"x",val:0.5},
      priority:2
    },
    {
      name:"Ranged Mastery",
      text:"Become a master of the bow",
      rarity:"Very Rare",
      mSpeed:{op:"x",val:0.5},
      mDam:{op:"x",val:0.5},
      mRange:{op:"x",val:0.5},
      rSpeed:{op:"x",val:1.5},
      rDam:{op:"x",val:1.5},
      rRange:{op:"x",val:1.5},
      priority:2
    },
    {
      name:"Sniper",
      text:"Don't get hit.",
      rarity:"Very Rare",
      maxHealth:{op:"x",val:0.25},
      mSpeed:{op:"x",val:0.25},
      mDam:{op:"x",val:0.25},
      mRange:{op:"x",val:0.25},
      rDam:{op:"x",val:4},
      rRange:{op:"x",val:4},
      priority:3,
    },
    {
      name:"Lightning Rod",
      text:"Zappy Zappy",
      rarity:"Very Rare",
      special:"Lightning",
      priority:4
    },
    {
      name:"POW Block",
      rarity:"Very Rare",
      onActivate:()=>{
        for(let s of sprites){
          if(s.alliance != "player"){
            try{
              s.hp -= 7.5;
            }catch{}
          }
          eventQue.push({
            type:"setShake",
            dur:10,int:5
          });
        }
      },
      charges:10
    },
    //Rare
    {
      name:"Speedrunning Serum",
      text:"Your welcome",
      speed:{op:"+",val:3},
      rarity:"Rare",
      special:"Fast Boss",
      priority:1.5
    },
    {
      name:"Polish",
      text:"Buff yourself up",
      rarity:"Rare",
      speed:{op:"+",val:2},
      maxHealth:{op:"+",val:2},
      mSpeed:{op:"+",val:2},
      mDam:{op:"+",val:2},
      mRange:{op:"+",val:2},
      rSpeed:{op:"+",val:2},
      rDam:{op:"+",val:2},
      rRange:{op:"+",val:2},
      priority:1,
    },
    {
      name:"Claymore",
      text:"Hit hard, but slow",
      rarity:"Rare",
      mSpeed:{op:"-",val:5},
      mDam:{op:"+",val:10},
      priority:1
    },
    {
      name:"Back to Basics",
      text:"Better basic stats",
      rarity:"Rare",
      speed:{op:"x",val:1.25},
      maxHealth:{op:"x",val:1.25},
      mSpeed:{op:"x",val:1.25},
      mDam:{op:"x",val:1.25},
      mRange:{op:"x",val:1.25},
      rSpeed:{op:"x",val:1.25},
      rDam:{op:"x",val:1.25},
      rRange:{op:"x",val:1.25},
      priority:0.75
    },
    {
      name:"Heart in a jar",
      text:"A reserve of health",
      rarity:"Rare",
      maxHealth:{op:"x",val:1.5},
      priority:2,
    },
    new Constants.items.steroids(),
    //Uncommon
    {
      name:"Winged shoes",
      text:"Walk on air",
      rarity:"Uncommon",
      special:"Floating",
      priority:4
    },
    {
      name:"Demon Horn",
      text:"Sharp and light",
      rarity:"Uncommon",
      mSpeed:{op:"+",val:3},
      mDam:{op:"+",val:3},
      priority:1,
    },
    {
      name:"Poker",
      text:"Long and pointy",
      rarity:"Uncommon",
      mRange:{op:"+",val:3},
      mDam:{op:"+",val:3},
      priority:1
    },
    {
      name:"Precision Arrows",
      text:"Exquisitly crafted",
      rarity:"Uncommon",
      rRange:{op:"+",val:3},
      rDam:{op:"+",val:3},
      rSpeed:{op:"+",val:3},
      priority:1
    },
    {
      name:"Breastplate",
      text:"Thick and strong, but suprisingly light",
      rarity:"Uncommon",
      maxHealth:{op:"+",val:25},
      priority:1
    },
    {
      name:"Magnet",
      text:"Grab everything",
      rarity:"Uncommon",
      special:"Magnetic",
      priority:4
    },
    //Common:
    {
      name:"Speed Charm",
      text:"Simple, but useful",
      rarity:"Common",
      speed:{op:"+",val:1},
      priority:1
    },
    {
      name:"Health Charm",
      text:"A tiny ruby cut into a heart",
      rarity:"Common",
      maxHealth:{op:"+",val:5},
      priority:1
    },
    {
      name:"Quick Cut Charm",
      text:"Average",
      rarity:"Common",
      mSpeed:{op:"+",val:1},
      priority:1
    },
    {
      name:"Cleaving Charm",
      text:"Half of a cleanly split skull",
      rarity:"Common",
      mDam:{op:"+",val:1},
      priority:1
    },
    {
      name:"Longsword Charm",
      text:"Not the greatest",
      rarity:"Common",
      mRange:{op:"+",val:1},
      priority:1
    },
    {
      name:"Fastflight Charm",
      text:"OK",
      rarity:"Common",
      rSpeed:{op:"+",val:1},
      priority:1
    },
    {
      name:"Piercing Charm",
      text:"An obsidian arrowhead",
      rarity:"Common",
      rDam:{op:"+",val:1},
      priority:1
    },
    {
      name:"Longbow Charm",
      text:"Mediocre",
      rarity:"Common",
      rRange:{op:"+",val:1},
      priority:1
    }
  ],
  synergies: [
    {
      components:[
        "Speed Charm","Health Charm","Quick Cut Charm",
        "Cleaving Charm","Longsword Charm",
        "Fastflight Charm","Piercing Charm","Longbow Charm"
      ],
      item: {
        name:"Master of Charms",
        text:"Together, they have great power",
        rarity:"Synergy",
        speed:{op:"+",val:5},
        maxHealth:{op:"+",val:5},
        mSpeed:{op:"+",val:5},
        mDam:{op:"+",val:5},
        mRange:{op:"+",val:5},
        rSpeed:{op:"+",val:5},
        rDam:{op:"+",val:5},
        rRange:{op:"+",val:5},
        priority:1
      }
    },
    {
      components:["Melee Mastery","Ranged Mastery"],
      item: {
        name:"True Mastery",
        text:"With knowledge of bow and sword, you are truly superior",
        rarity:"Synergy",
        speed:{op:"x",val:3},
        maxHealth:{op:"x",val:3},
        mSpeed:{op:"x",val:3},
        mDam:{op:"x",val:3},
        mRange:{op:"x",val:3},
        rSpeed:{op:"x",val:3},
        rDam:{op:"x",val:3},
        rRange:{op:"x",val:3},
        priority:2
      }
    }
  ],
  rarityVals: {
    "Ledgendary":1,
    "Very Rare":3,
    "Rare":6,
    "Uncommon":9,
    "Common":12,
    "Debug":1000,
  },
  costs: {
    "Ledgendary":50,
    "Very Rare":20,
    "Rare":10,
    "Uncommon":5,
    "Common":3,
    "Dust":0
  },
  update: ()=>{
    //check for synergies
    let syns = [];
    let items = heldItems.items.map(i=>{return i.name});
    for (let syn of heldItems.synergies){
      let add = true;
      for(let req of syn.components){
        if(items.indexOf(req)==-1){
          add = false;
        }
      }
      if(add){
        syns.push(syn);
      }
    }
    //filter gotten
    syns = syns.filter(s=>{
      return heldItems.gottenSyns.indexOf(s.item.name)==-1;
    });
    //add to gotten and items
    for(let syn of syns){
      heldItems.gottenSyns.push(syn.item.name);
      heldItems.items.push(syn.item);
    }
    //sort items
    heldItems.items.sort((a,b)=>{return a.priority-b.priority});
    //setup rows
    let rows = {
      name:["Name:"],
      text:["Description:"],
      rarity:["Rarity:"],
      speed:["Speed:"],
      maxHealth:["Max Health:"],
      mSpeed:["Melee Speed:"],
      mDam:["Melee Damage:"],
      mRange:["Melee Range:"],
      rSpeed:["Ranged Speed:"],
      rDam:["Ranged Damage:"],
      rRange:["Arrow Size:"],
      special:["Effects:"]
    };
    for(let item of heldItems.items){
      for(let row of Object.keys(rows)){
        rows[row].push(item[row]||"");
      }
    }
    //calculate totals
    let stats = Object.assign({},rows);
    for(let row of Object.keys(stats)){
      if(row=="name"||row=="text"||row=="special"||row=="rarity"){
        delete stats[row];
      } else {
        stats[row] = stats[row]
          .filter(t=>{return t.op!=undefined})
          .reduce((a,b)=>{
            let op = {
              "+":(a,b)=>{return a+b;},
              "-":(a,b)=>{return a-b;},
              "x":(a,b)=>{return a*b;},
              "=":(a,b)=>{return b;}
            }[b.op];
            return op(a,b.val);
          },0);
        if(row=="speed"){
          stats[row] = Math.floor(Math.min(stats[row],30));
        }
      }
    }
    //effects
    stats.special = rows.special.filter(e=>{return e!="Effects:"&&e!=""});
    //update stats
    heldItems.stats = stats;
    //update rows
    for(let row of Object.keys(stats)){
      rows[row][1] = stats[row];
    }
    //remove DOM
    heldItems.dom.remove();
    //build DOM
    let dom = document.createElement("table");
    //build rows
    for(let row of Object.keys(rows)){
      let dRow = document.createElement("tr");
      for(let item of rows[row]){
        let text;
        if(item.op==undefined){
          text = item;
        } else {
          text = item.op+item.val;
        }
        let cell = document.createElement("td");
        cell.appendChild(document.createTextNode(text));
        dRow.appendChild(cell);
        cell = document.createElement("td");
        cell.style.width = 5;
        dRow.appendChild(cell);
      }
      dom.appendChild(dRow);
    }
    //update dom
    heldItems.dom = dom;
    let cont = document.getElementById("itemCont");
    cont.appendChild(heldItems.dom);
  },
  addItem: item=>{
    if(!item.onActivate){
      //add to held items
      heldItems.items.push(item);
      //call item's onGet if present
      if(item.onGet){
        item.onGet();
      }
      //update tracker
      heldItems.update();
    } else {
      heldItems.activeItem.item = item;
      heldItems.activeItem.charges = item.charges;
    }
    //remove from item pool
    heldItems.itemPool = heldItems.itemPool.filter(i=>{return i!=item});
  },
  getItem: ()=>{
    //build weighted pool
    let wPool = [];
    for(let item of heldItems.itemPool){
      for(let i=0;i<heldItems.rarityVals[item.rarity];i++){
        wPool.push(item.name);
      }
    }
    //draw remove, and return
    let iName = Array.randElem(wPool);
    let ret = heldItems.itemPool.filter(i=>{
      return i.name == iName;
    })[0];
    heldItems.itemPool = heldItems.itemPool.filter(i=>{
      return i.name != iName
    });
    //remove from item pool
    heldItems.itemPool = heldItems.itemPool.filter(i=>{return i!=ret});
    //return
    return ret;
  },
  getCost: cost=>{
    return cost;
  },
  chargeActive: ()=>{
    heldItems.activeItem.charges = Math.min(
      heldItems.activeItem.charges + 1,
      heldItems.activeItem.item.charges
    );
  },
  useActive: ()=>{
    if(
      heldItems.activeItem.charges ==
      heldItems.activeItem.item.charges
    ){
      heldItems.activeItem.charges = 0;
      heldItems.activeItem.item.onActivate();
    }
  },
  gottenSyns: [],
  dom: {remove:()=>{}}
};

/*
ClassesLoader loads:
  Classes
  Anims loads:
    Run
*/
load("scripts/classes/classesLoader.js",true);
