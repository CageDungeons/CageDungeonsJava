//Enable strict mode
"use strict";

//sprite bases
class CollidingSprite extends Sprite {
  constructor(x,y,w,h,xo,yo,flying,animator){
    super(x,y,animator);
    this.w = w;
    this.h = h;
    this.xo = xo;
    this.yo = yo;
    this.flying = flying;
    this.collision = [
      "w","wn","ws","we","ww","dh",
      "wnd2","wnd","b","cl","cr","dne"
    ];
    this.flyOver = ["p","pt","ptd"];
  }
  tick(xDir,yDir,tiles,speed,events){
    speed = Math.floor(Math.min(speed,30));
    //get collision events
    let colEvs = events.filter(e=>{return e.type=="collision"});
    //collision
    let col = this.collision.slice();
    if(!this.flying) {col = col.concat(this.flyOver)};
    [this.x,this.y] = collide(
      this.x+this.xo,
      this.y+this.yo,
      this.w,this.h,
      speed,xDir,yDir,
      (x,y,w,h)=>{
        return touchingTiles(tiles,col,x,y,w,h) ||
        colEvs.reduce((a,b)=>{
          return a||overlaps(x,y,w,h,b.x,b.y,b.w,b.h)
        },false)
      }
    );
    this.x -= this.xo;
    this.y -= this.yo;
    //animation
    super.tick();
  }
}

class MOB extends CollidingSprite {
  constructor(x,y,w,h,xo,yo,flying,hp,alliance,animator){
    super(x,y,w,h,xo,yo,flying,animator);
    this.hp = hp;
    this.hit = [];
    this.alliance = alliance;
    this.ID = getID();
  }
  tick(xDir,yDir,speed,events){
    //hit source resets
    let resets = events
    .filter(e=>{return e.type=="reset"})
    .map(e=>{return e.ID});
    this.hit = this.hit.filter(
      h=>{return resets.indexOf(h[0])==-1}
    );
    //cooldowns
    this.hit = this.hit
      .map(h=>{
        if(h[1]=="none") {
          return h;
        }
        return [h[0],h[1]-1];
      })
      .filter(
        h=>{return h[1]!=0}
      );
    //check for damage
    let damages = events.filter(
      e=>{return e.type=="damage"}
    );
    for(let d of damages){
      if(
        this.alliance != d.alliance &&
        this.hit.filter(h=>{return h[0]==d.ID}).length == 0 &&
        overlaps(
          this.x+this.xo,this.y+this.yo,this.w,this.h,
          d.x,d.y,
          d.w,d.h
      )) {
        this.hit.push([d.ID,d.cool||"none"]);
        this.hp -= d.power;
        if(
          d.effects &&
          d.effects.indexOf("lightning")!=-1 &&
          Math.random()<0.5
          ){
          sprites.push(
            new Lightning(this.x,this.y,d.alliance,d.ID)
          );
        }
        this.onHit(d.power);
      }
    }
    //check for death
    if(this.hp<=0){
      //removal
      sprites = sprites.filter(s=>{return s!=this;});
    }
    //everyting else
    super.tick(xDir,yDir,rooms,speed,events);
  }
  get events() {
    return [];
  }
  onHit() {}
}

class Enemy extends MOB {
  constructor(x,y,w,h,xo,yo,flying,hp,alliance,value,cChance,animator){
    super(x,y,w,h,xo,yo,flying,hp,alliance,animator);
    this.value = value*(cChance/diff[area]);
    this.cChance = cChance;
  }
  tick(xDir,yDir,speed,events){
    super.tick(xDir,yDir,speed,events);
    if(this.hp<=0){
      for(;this.value>=1;this.value--){
        sprites.push(new BasicItem(this.x,this.y,"coins"));
      }
      if(Math.random()<this.value){
        sprites.push(new BasicItem(this.x,this.y,"coins"));
      }
    }
  }
}

//player
class Player extends MOB {
  constructor(x,y){
    super(
      x,y,28,30,2,0,false,heldItems.stats.maxHealth,
      "player",new Animator(anims.player,"idle")
    );
    this.speed = 6;
    this.hpMO = heldItems.stats.maxHealth;
    this.bombDropped = false;
    this.rCool = 0;
    this.weapon = new Weapon(
      this.x,this.y,40,"player",0,1,1,60
    );
    this.spriteType = "player";
  }
  tick(events) {
    //update stats
    this.speed = heldItems.stats.speed;
    this.hp += Math.abs(heldItems.stats.maxHealth - this.hpMO);
    this.hp = Math.min(this.hp,heldItems.stats.maxHealth);
    this.hpMO = heldItems.stats.maxHealth;
    if(heldItems.stats.special.indexOf("Floating")>-1){
      this.flying = true;
    }
    //weapon stats
    this.weapon.size = (heldItems.stats.mRange/2)+0.5;
    this.weapon.power = heldItems.stats.mDam;
    this.weapon.coolTime = Math.floor(Math.max(60-(heldItems.stats.mSpeed*5),5));
    if(this.weapon.effects.indexOf("lightning")==-1&&heldItems.stats.special.indexOf("Lightning")!=-1){
      this.weapon.effects.push("lightning");
    }
    //get target angle
    let pos = Mouse.toCanvas(canvas.canvas,Mouse.x,Mouse.y);
    let angle = Math.angle(
      pos.x-canvas.canvas.width/2,
      pos.y-canvas.canvas.height/2
    )-Math.PI/2;
    //update weapon
    this.weapon.angle = angle;
    this.weapon.x = this.x+16;
    this.weapon.y = this.y+16;
    if(actions.mAttack){
      this.weapon.swing();
    }
    this.weapon.tick();
    //ranged attack
    if(actions.rAttack&&this.rCool==0){
      this.rCool = Math.floor(Math.max(60-(heldItems.stats.rSpeed*5),1));
      sprites.push(
        new Arrow(this.x,this.y,20,"player",
        heldItems.stats.rDam,angle,
        (100+(heldItems.stats.rRange*5))/100
        )
      );
    }
    if(this.rCool>0){
      this.rCool -= 1;
    }
    //bombs
    if(actions.bomb&&!this.bombDropped&&heldItems.basicItems.bombs>0){
      this.bombDropped = true;
      sprites.push(new Bomb(this.x,this.y,100,5));
      heldItems.basicItems.bombs -= 1;
    }
    if(!actions.bomb){
      this.bombDropped = false;
    }
    //active item use
    if(actions.useActive){
      heldItems.useActive();
    }
    //magnetism
    if(heldItems.stats.special.indexOf("Magnetic")>-1){
      for(let s of sprites){
        if([
          "item",
          "basicItem",
          "healingItem"
        ].indexOf(s.spriteType)>-1){
          let rx = s.x - this.x;
          let ry = s.y - this.y;
          let ds = rx*rx+ry*ry;
          if(ds<=256*256){
            s.x -= 2*((rx<0)?-1:1);
            s.y -= 2*((ry<0)?-1:1);
          }
        }
      }
    }
    //slow movement
    let speed = this.speed;
    if(actions.slow){
      speed = 3;
    }
    //movement
    let xDir = -1;
    let yDir = -1;
    if(actions.moveN){
      this.y -= speed;
    }
    if(actions.moveE){
      this.x -= speed;
    }
    if(actions.moveS){
      this.y += speed;
      yDir = 1;
    }
    if(actions.moveW){
      this.x += speed;
      xDir = 1;
    }
    if(actions.moveN && !actions.moveS){
      this.animator.current = "walkUp";
    }
    if(actions.moveS && !actions.moveN){
      this.animator.current = "walkDown";
    }
    if(actions.moveE && !actions.moveW){
      this.animator.current = "walkLeft";
    }
    if(actions.moveW && !actions.moveE){
      this.animator.current = "walkRight";
    }
    //defaults
    super.tick(xDir,yDir,speed,events);
    //death message
    if(this.hp<=0) {alert(
      `
        You Died :(
        Reload to restart
      `
    )}
  }
  draw(ctx,cx,cy){
    super.draw(ctx,cx,cy);
    this.weapon.draw(ctx,cx,cy);
  }
  onHit(dam){
    eventQue.push({
      type:"setShake",
      dur:10+dam,
      int:Math.max(dam,3)
    });
  }
  get events() {
    return [{
      type:"player",
      x:this.x,
      y:this.y,
      w:32,
      h:32
    }].concat(this.weapon.events);
  }
}
