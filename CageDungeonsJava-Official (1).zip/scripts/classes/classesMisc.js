//Enable strict mode
"use strict";

class Chest extends Sprite {
  constructor(x,y,type){
    super(x,y,new Animator(anims.chest,type));
    this.type = type;
    this.spriteType = "chest";
  }
  tick(events){
    //tick animations
    super.tick();
    //check for player
    let player = events.filter(
      (e) => {return e.type=="player"}
    )[0];
    if(
      actions.interact &&
      overlaps(
        this.x,this.y,32,32,
        player.x,player.y,
        player.w,player.h
    )) {
      //get pool
      let pool = {
        gold:[0,0,0].concat(buildRand("coins",8)),
        item:[15,10,10,10,5,5,5,5,5,5,5,5,5].concat(
          buildRand("keys",15)).concat(
          buildRand("bombs",15)).concat(
          buildRand(0,45))
      }[this.type];
      if(heldItems.stats.special.indexOf("Chest Recursion")!=-1){
        pool = pool.concat(buildRand("chest",5));
      }
      //randomize and pick
      pool.sort((a,b)=>{return Math.random()-0.5});
      pool = pool.slice(0,8);
      //create and add sprites
      for(let i=0;i<8;i++){
        let pos = [
          [-40,-40],[0,-40],[40,-40],[40,0],
          [40,40],[0,40],[-40,40],[-40,0]
        ][i];
        let item = pool[i]
        if(["coins","keys","bombs"].indexOf(item)!=-1){
          sprites.push(
            new BasicItem(
              this.x + pos[0],this.y+pos[1],item
            )
          );
        } else if(item=="chest"){
          sprites.push(
            new Chest(
              this.x + pos[0],this.y+pos[1],this.type
            )
          );
        }else if(item != 0){
          sprites.push(
            new HealingItem(
              this.x + pos[0],this.y+pos[1],item
            )
          );
        }
      }
      //delete self
      sprites = sprites.filter(s=>{return s!=this});
    }
  }
}

class Rock extends Sprite {
  constructor(x,y){
    super(x,y,new Animator(anims.rock,"idle"));
    this.spriteType = "rock";
  }
  tick(events){
    //tick animations
    super.tick();
    //check for explosion
    let exps = events.filter(
      (e) => {return e.damType=="explosion"}
    );
    for(let e of exps){
      if(
        overlaps(
          this.x,this.y,32,32,
          e.x,e.y,
          e.w,e.h
      )) {
        //get item
        let item = Array.randElem(
          [15,10,10,10].concat(
            buildRand(0,15)).concat(
            buildRand("moreBomb",6)).concat(
            buildRand("bombs",15)).concat(
            buildRand("keys",15)).concat(
            buildRand(5,9))
        );
        //generate
        if(["coins","keys","bombs"].indexOf(item)!=-1){
          sprites.push(
            new BasicItem(
              this.x,this.y,item
            )
          );
        } else if(item == "moreBomb"){
          sprites.push(
            new Bomb(
              this.x,this.y,25,10
            )
          );
        } else if(item != 0){
          sprites.push(
            new HealingItem(
              this.x,this.y,item
            )
          );
        }
        //delete self
        sprites = sprites.filter(s=>{return s!=this});
      }
    }
  }
  get events() {
    return [{
      type:"collision",
      x:this.x,
      y:this.y,
      w:32,
      h:32
    }];
  }
}

class Thing extends Sprite {
  constructor(x,y,type,animator){
    super(x,y,animator);
    this.spriteType = type;
  }
  get events() {
    return [{
      type:"collision",
      x:this.x,
      y:this.y,
      w:32,
      h:32
    }];
  }
}

class Bomb extends Sprite {
  constructor(x,y,timer,power){
    super(x,y,new Animator(anims.bomb,"idle")),
    this.fuse = timer;
    this.power = power;
    this.size = 32;
    this.ID = getID();
  }
  tick(){
    this.fuse -= 1;
    if(this.fuse < 1){
      this.animator.current = "exploding";
    }
    if(this.fuse < -10){
      sprites = sprites.filter(s=>{return s!=this});
    }
    super.tick();
  }
  get events() {
    if(this.fuse < 1){
      return [
        {
          type:"damage",
          damType:"explosion",
          x:this.x - 32,
          y:this.y - 32,
          w:96,h:96,
          power:this.power,
          alliance:"envirnment",
          ID:this.ID
        },{
          type:"setShake",
          dur:30,int:d=>{return d/6}
        }
      ];
    } else {
      return [];
    }
  }
}

class Weapon extends Sprite {
  constructor(
    x,y,ofset,alliance,angle,size,power,coolTime,
    animator=new Animator(anims.sword,"held")
  ){
    super(x,y,animator);
    this.alliance = alliance;
    this.angle = angle;
    this.ofset = ofset;
    this.size = size;
    this.power = power;
    this.coolTime = coolTime;
    this.cool = 0;
    this.ID = getID();
    this.effects = [];
  }
  tick(){
    if(this.cool > this.coolTime*0.75){
      this.animator.current = "swinging";
    } else {
      this.animator.current = "held";
    }
    if(this.cool > 0){
      this.cool -= 1;
    }
    super.tick();
  }
  draw(ctx,cx,cy){
    //rotation math
    let frame = this.animator.frame;
    let size = Math.sqrt(
      frame.width*frame.width +
      frame.height*frame.height
    )*this.size;
    let x = this.x+Math.sin(-this.angle)*this.ofset-size/2;
    let y = this.y+Math.cos(-this.angle)*this.ofset-size/2;
    //hitbox generation
    this.hitbox = {
      x:x,y:y,w:size,h:size,
      alliance:this.alliance,
      power:this.power,
      type:"damage",
      effects:this.effects,
      ID:this.ID,
      alliance:this.alliance
    };
    ctx.drawImage(
      Canvas.rotate(
        Canvas.scale(
          frame,this.size*frame.width,
          this.size*frame.height
        ),
        this.angle+Math.PI*0.75),
      x-cx,
      y-cy
    );
  }
  swing() {
    if(this.cool < 1){
      this.cool = this.coolTime;
    }
  }
  get events() {
    let ret = [];
    if(this.cool > this.coolTime*0.75){
      ret.push(this.hitbox);
    }
    if(this.cool == 1){
      ret.push({type:"reset",ID:this.ID});
    }
    return ret;
  }
}

class Arrow extends Sprite {
  constructor(x,y,speed,alliance,damage,angle,size){
    super(x,y,new Animator(anims.arrow,"shot"));
    this.speed = speed;
    this.alliance = alliance;
    this.power = damage;
    this.angle = angle;
    this.size = size;
    this.xv = Math.sin(-angle)*speed;
    this.yv = Math.cos(-angle)*speed;
    this.ID = getID();
    this.hitbox = {
      x:this.x,y:this.y,w:32,h:32,
      alliance:this.alliance,
      power:this.power,
      type:"damage",
      ID:this.ID,
      alliance:this.alliance
    };
    this.spriteType = "arrow";
  }
  tick(events){
    //move
    this.x += this.xv;
    this.y += this.yv;
    //get collision events
    let colEvs = events.filter(e=>{return e.type=="collision"});
    //collision
   if(touchingTiles(rooms,[
      "w","wn","ws","we","ww","dh",
      "wnd2","wnd","b","cl","cr"
    ],this.x,this.y,32,32) ||
      colEvs.reduce((a,b)=>{
        return a||overlaps(
          this.hitbox.x,this.hitbox.y,
          this.hitbox.w,this.hitbox.h,
          b.x,b.y,b.w,b.h
        )
      },false)
   ){
     sprites = sprites.filter(s=>{return s!=this});
   }
    //defaults
    super.tick();
  }
  draw(ctx,cx,cy){
    //rotation math
    let frame = this.animator.frame;
    let size = Math.sqrt(
      frame.width*frame.width +
      frame.height*frame.height
    )*this.size;
    //hitbox generation
    this.hitbox = {
      x:this.x,y:this.y,w:size,h:size,
      alliance:this.alliance,
      power:this.power,
      type:"damage",
      ID:this.ID
    };
    ctx.drawImage(
      Canvas.rotate(
        Canvas.scale(
          frame,this.size*frame.width,
          this.size*frame.height
        ),
        this.angle+Math.PI*0.75),
      this.x-cx,
      this.y-cy
    );
  }
  get events() {
    return [this.hitbox];
  }
}

class Lightning extends Sprite {
  constructor(x,y,alliance,id){
    super(x-16,y-16,new Animator(anims.lightning,"shocking"));
    this.alliance = alliance;
    this.ID = id;
    this.timer = 10;
  }
  tick(){
    this.timer -= 1;
    if(this.timer < 0){
      sprites = sprites.filter(s=>{return s!= this});
    }
    super.tick();
  }
  get events() {
    return [{
      type:"damage",
      x:this.x,y:this.y,
      w:64,h:64,
      effects:["lightning"],
      alliance:this.alliance,
      power:2,ID:this.ID
    }];
  }
}

class PathNode {
  constructor(x,y,tile,roomID){
    this.x = x;
    this.y = y;
    this.tile = tile;
    this.id = roomID;
    this.links = [];
  }
  link(other){
    this.links.push(other);
    other.links.push(this);
  }
  draw(ctx,cx,cy){
    ctx.beginPath();
    ctx.fillStyle = "white";
    ctx.strokeStyle =" white";
    ctx.arc(this.x-cx,this.y-cy,5,0,7);
    ctx.fill();
    for(let l of this.links){
      ctx.beginPath();
      ctx.moveTo(this.x-cx,this.y-cy);
      ctx.lineTo(l.x-cx,l.y-cy);
      ctx.stroke();
    }
  }
}

class ScreenShake {
  constructor(){
    this.durLeft = 0;
    this.int = 0;
    this.shake = {x:0,y:0};
  }
  setShake(dur,int){
    this.durLeft = dur;
    this.int = int;
  }
  tick(events){
    //check for sets
    let e = events.filter(e=>{return e.type=="setShake"})[0];
    if(e) this.setShake(e.dur,e.int);
    //update shake
    if(this.durLeft > 0){
      this.durLeft -= 1;
      //get intensity
      let int = this.int;
      if(typeof this.int == typeof this.tick) {
        int = this.int(this.durLeft);
      }
      if(!int.x) int = {x:int,y:int};
      //calculate
      this.shake = {
        x:this.genShake(int.x),
        y:this.genShake(int.y)
      }
    }
  }
  genShake(int){
    let r = Math.random()-0.5;
    return r*int;
  }
}

class Timeout {
  constructor(delay,preset){
    this.left = preset||delay;
    this.delay = delay;
  }
  tick(){
    if(!this.ready) this.left--
  }
  get ready() {
    return this.left<=0;
  }
  activate() {
    this.left = this.delay
  }
}

//navigation
class Door extends Sprite {
  constructor(x,y,mx,my,dir){
    let type = map[my][mx];
    super(x,y,new Animator(anims.door,dir + "_" + area));
    this.mx = mx;
    this.my = my;
    this.dir = dir;
    this.spriteType = "door";
    //setup extension
    if(dir == "e" || dir == "w"){
      this.ext = new Sprite(
        x,y-Constants.sizes.tileSize.y,new Animator(
          anims.doorExt,dir + "_" + area
        )
      );
    }
  }
  tick(events) {
    //tick animations
    super.tick();
    //check for player
    let player = events.filter(
      (e) => {return e.type=="player"}
    )[0];
    if(
      overlaps(
        this.x-5,this.y-5,
        Constants.sizes.tileSize.x+10,
        Constants.sizes.tileSize.y+10,
        player.x,player.y,
        player.w,player.h
      ) && actions.interact
    ) {
      //Turmoil item
      if(heldItems.stats.special.indexOf("Random Stats")>-1){
        for(let stat of ["speed","maxHealth","mSpeed","mDam","mRange","rSpeed","rDam","rRange"]){
          heldItems.items[1][stat] = {op:"+",val:Math.floor(Math.random()*100)+1};
        }
        heldItems.update();
      }
      //active item charging
      heldItems.chargeActive();
      //build room
      buildRoom(
        map,this.mx,
        this.my,
        roomTemps
      );
    }
  }
  draw(ctx,cx,cy) {
    super.draw(ctx,cx,cy);
    //draw extention
    if(this.dir == "e" || this.dir == "w"){
      this.ext.draw(ctx,cx,cy);
    }
  }
  get events() {
    return [{
      type:"collision",
      x:this.x,
      y:this.y,
      w:Constants.sizes.tileSize.x,
      h:Constants.sizes.tileSize.y
    }];
  }
}

class AreaChange extends Sprite {
  constructor(x,y){
    super(x,y,new Animator(anims.areaChange,"idle"));
    this.spriteType = "portal";
  }
  tick(events){
    //animations
    super.tick();
    //check for player
    let player = events.filter(
      (e) => {return e.type=="player"}
    )[0];
    if(
      actions.interact &&
      overlaps(
        this.x,this.y,32,32,
        player.x,player.y,
        player.w,player.h
    )) {
      //clear rooms
      rooms = [];
      //clear map
      map = [
        ["e","e","e","e","e","e","e","e","e"],
        ["e","e","e","e","e","e","e","e","e"],
        ["e","e","e","e","e","e","e","e","e"],
        ["e","e","e","e","e","e","e","e","e"],
        ["e","e","e","e","f","e","e","e","e"],
        ["e","e","e","e","e","e","e","e","e"],
        ["e","e","e","e","e","e","e","e","e"],
        ["e","e","e","e","e","e","e","e","e"],
        ["e","e","e","e","e","e","e","e","e"],
      ];
      //clear visited rooms
      visited = [];
      //clear generation parameters
      chances = {
        boss: (heldItems.stats.special.indexOf("Fast Boss")>-1)?1:0,
        item: 0,
        shop: 0,
        mini: 0,
        doorFreq: [1,1,1,1,1,2,2,2,2,3,3,4]
      };
      //clear sprites (except for player)
      let player = sprites.filter(s=>{return s.spriteType=="player"})[0];
      sprites = [player];
      //reset player to map center
      player.x = playerStart.x;
      player.y = playerStart.y;
      //change area
      area = Array.randElem(aTM[area]);
      //generate starting room
      buildRoom(
        map,mapCenter.x,mapCenter.y,
        roomTemps
      );
    }
  }
}

class LockedDoor extends Sprite {
  constructor(x,y,dir){
    super(x,y,new Animator(anims.door,"n_" + area));
    this.spriteType = "lockedDoor";
  }
  tick(events) {
    //tick animations
    super.tick();
    //check for player
    let player = events.filter(
      (e) => {return e.type=="player"}
    )[0];
    if(
      actions.interact &&
      heldItems.basicItems.keys > 0 &&
      overlaps(
        this.x-5,this.y-5,
        Constants.sizes.tileSize.x+10,
        Constants.sizes.tileSize.y+10,
        player.x,player.y,
        player.w,player.h
    )) {
      //take key
      heldItems.basicItems.keys -= 1;
      //delete self
      sprites = sprites.filter(s=>{return s!=this});
    }
  }
  get events() {
    return [{
      type:"collision",
      x:this.x,
      y:this.y,
      w:Constants.sizes.tileSize.x,
      h:Constants.sizes.tileSize.y
    }];
  }
}
