//Enable strict mode
"use strict";

//items
class Item extends Sprite {
  constructor(x,y){
    let item = heldItems.getItem()||{
      name:"Pile of Dust",
      text:"Completely useless",
      priority:10000
    };
    super(x,y,new Animator(anims.item,item.name));
    this.item = item;
    this.spriteType = "item";
  }
  tick(events) {
    //tick animations
    super.tick();
    //check for player
    let player = events.filter(
      (e) => {return e.type=="player"}
    )[0];
    if(
      actions.interact &&
      overlaps(
        this.x,this.y,32,32,
        player.x,player.y,
        player.w,player.h
    )) {
      //give item
      heldItems.addItem(this.item);
      //delete self
      sprites = sprites.filter(s=>{return s!=this});
    }
  }
}

class ShopItem extends Sprite {
  constructor(x,y){
    let item = heldItems.getItem()||{
      name:"Pile of Dust",
      text:"Completely useless",
      priority:10000
    };
    super(x,y,new Animator(anims.item,item.name));
    this.item = item;
    let rarity = this.item.rarity||"Dust";
    this.baseCost = heldItems.costs[rarity];
    this.touching = false;
    this.spriteType = "shopItem";
  }
  tick(events){
    //tick animations
    super.tick();
    //check for player
    let player = events.filter(
      (e) => {return e.type=="player"}
    )[0];
    if(
      overlaps(
        this.x,this.y,32,32,
        player.x,player.y,
        player.w,player.h
      )
    ){
      this.touching = true;
      if(
        actions.interact &&
        heldItems.getCost(this.baseCost) <= 
        heldItems.basicItems.coins
        ) {
        //give item
        heldItems.addItem(this.item);
        //take coins
        heldItems.basicItems.coins -= heldItems.getCost(this.baseCost);
        //delete self
        sprites = sprites.filter(s=>{return s!=this});
      }
    } else {
      this.touching = false;
    }
  }
  draw(ctx,cx,cy){
    super.draw(ctx,cx,cy);
    ctx.beginPath();
    ctx.fillStyle = "white";
    ctx.font = "15px serif";
    ctx.fillText(
      heldItems.getCost(this.baseCost),
      this.x-cx+10,this.y-cy
    );
    ctx.closePath();
  }
}

class BasicItem extends Sprite {
  constructor(x,y,type){
    super(x,y,new Animator(anims.basicItem,type));
    this.type = type;
    this.spriteType = "basicItem";
  }
  tick(events){
    //tick animations
    super.tick();
    //check for player
    let player = events.filter(
      (e) => {return e.type=="player"}
    )[0];
    if(
      overlaps(
        this.x,this.y,32,32,
        player.x,player.y,
        player.w,player.h
    )) {
      //give item
      heldItems.basicItems[this.type] += 1;
      //delete self
      sprites = sprites.filter(s=>{return s!=this});
    }
  }
}

class ShopBasicItem extends Sprite {
  constructor(x,y){
    let type = Array.randElem(["keys","bombs"]);
    super(x,y,new Animator(anims.basicItem,type));
    this.type = type;
    this.spriteType = "shopBasicItem";
  }
  tick(events){
    //tick animations
    super.tick();
    //check for player
    let player = events.filter(
      (e) => {return e.type=="player"}
    )[0];
    if(
      actions.interact &&
      heldItems.basicItems.coins >= 5 &&
      overlaps(
        this.x,this.y,32,32,
        player.x,player.y,
        player.w,player.h
    )) {
      //take coins
      heldItems.basicItems.coins -= 5;
      //give item
      heldItems.basicItems[this.type] += 1;
      //delete self
      sprites = sprites.filter(s=>{return s!=this});
    }
  }
  draw(ctx,cx,cy){
    super.draw(ctx,cx,cy);
    ctx.beginPath();
    ctx.fillStyle = "white";
    ctx.font = "15px serif";
    ctx.fillText(
      5,this.x-cx+10,this.y-cy
    );
    ctx.closePath();
  }
}

class HealingItem extends Sprite {
  constructor(x,y,power){
    super(x,y,new Animator(anims.healingItem,power));
    this.power = power;
    this.spriteType = "healingItem";
  }
  tick(events){
    //tick animations
    super.tick();
    //check for player
    let player = events.filter(
      (e) => {return e.type=="player"}
    )[0];
    if(
      actions.interact &&
      overlaps(
        this.x,this.y,32,32,
        player.x,player.y,
        player.w,player.h
    )) {
      //give health
      let player = sprites.filter(
        s=>{return s.spriteType=="player"}
      )[0];
      player.hp += this.power;
      //delete self
      sprites = sprites.filter(s=>{return s!=this});
    }
  }
}

class ShopHealingItem extends Sprite {
  constructor(x,y){
    let power = Array.randElem([5,5,5,5,5,10,10,10,15]);
    super(x,y,new Animator(anims.healingItem,power));
    this.power = power;
    this.cost = Math.floor(power/2);
    this.spriteType = "shopHealingItem";
  }
  tick(events){
    //tick animations
    super.tick();
    //check for player
    let player = events.filter(
      (e) => {return e.type=="player"}
    )[0];
    if(
      actions.interact &&
      heldItems.basicItems.coins >= this.cost &&
      overlaps(
        this.x,this.y,32,32,
        player.x,player.y,
        player.w,player.h
    )) {
      //take coins
      heldItems.basicItems.coins -= this.cost;
      //give health
      let player = sprites.filter(
        s=>{return s.spriteType=="player"}
      )[0];
      player.hp += this.power;
      //delete self
      sprites = sprites.filter(s=>{return s!=this});
    }
  }
  draw(ctx,cx,cy){
    super.draw(ctx,cx,cy);
    ctx.beginPath();
    ctx.fillStyle = "white";
    ctx.font = "15px serif";
    ctx.fillText(
      this.cost,this.x-cx+10,this.y-cy
    );
    ctx.closePath();
  }
}
