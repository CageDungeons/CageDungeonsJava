//Enable strict mode
"use strict";

load("scripts/classes/classesBases.js",true);
load("scripts/classes/classesItems.js",true);
load("scripts/classes/classesEnemies.js",true);
load("scripts/classes/classesMisc.js",true);
load("scripts/classes/classesHUD.js",true);

/*
Anims loads:
      Run
*/
load("scripts/anims.js",true);
