//Enable strict mode
"use strict";

//enemies
class BasicEnemy extends Enemy {
  constructor(x,y,giveCoins=true){
    super(x,y,16,16,8,8,false,2*diff[area],"enemy",
    giveCoins?1:0,0.5,new Animator(anims.enemy,"idle" + "_" + area));
    this.speed = 2*diff[area];
  }
  tick(events){
    //get player
    let player = events.filter(e=>{return e.type=="player"})[0];
    //movement
    let xDir = -1;
    let yDir = -1;
    if(player.y < this.y){
      this.y -= this.speed;
      this.animator.current = "walkUp" + "_" + area;
    }
    if(player.y > this.y){
      this.y += this.speed;
      yDir = 1;
      this.animator.current = "walkDown" + "_" + area;
    }
    if(player.x < this.x){
      this.x -= this.speed;
      this.animator.current = "walkLeft" + "_" + area;
    }
    if(player.x > this.x){
      this.x += this.speed;
      xDir = 1;
      this.animator.current = "walkRight" + "_" + area;
    }
    //defaults
    super.tick(xDir,yDir,this.speed,events);
  }
  get events() {
    return [
      {type:"enemy"},
      {
        type:"damage",
        ID:this.ID,
        alliance:"enemy",
        power:5*diff[area],
        x:this.x + this.xo,
        y:this.y + this.yo,
        w:this.w,h:this.h,
        cool:100,
      }
    ];
  }
}

class RangedEnemy extends Enemy {
  constructor(x,y,giveCoins=true){
    super(x,y,16,16,8,8,true,diff[area],"enemy",
    giveCoins?1:0,0.65,new Animator(anims.enemy,"idle" + "_" + area));
    this.speed = 2*diff[area];
    this.arrowCool = Math.round(Math.random()*100);
  }
  tick(events){
    //get player
    let player = events.filter(e=>{return e.type=="player"})[0];
    //movement
    let xDir = -1;
    let yDir = -1;
    let rx = player.x - this.x;
    let ry = player.y - this.y;
    let distSquared = rx*rx + ry*ry;
    let angle = Math.angle(
      (player.x+player.w)-(this.x+this.w/2),
      (player.y+player.h)-(this.y+this.h/2)
    )-Math.PI/2;
    //run away from player if close
    if(distSquared < 25600){
      if(player.y > this.y){
        this.y -= this.speed;
        this.animator.current = "walkUp" + "_" + area;
      }
      if(player.y < this.y){
        this.y += this.speed;
        yDir = 1;
        this.animator.current = "walkDown" + "_" + area;
      }
      if(player.x > this.x){
        this.x -= this.speed;
        this.animator.current = "walkLeft" + "_" + area;
      }
      if(player.x < this.x){
        this.x += this.speed;
        xDir = 1;
        this.animator.current = "walkRight" + "_" + area;
      }
    } else {
      if(this.arrowCool<1){
        this.arrowCool = 200/diff[area];
        sprites.push(new Arrow(this.x,this.y,10,"enemy",1*diff[area],angle,1));
      }
    }
    //arrow cooldown
    if(this.arrowCool>0){
      this.arrowCool -= 1;
    }
    //defaults
    super.tick(xDir,yDir,this.speed,events);
  }
}

class ChestEnemy extends Enemy {
  constructor(x,y,type){
    super(x,y,16,16,8,8,false,2*diff[area],"enemy",
    0,0.5,new Animator(anims.chestEnemy,"idle" + "_" + type));
    this.speed = 2*diff[area];
    this.isActive = false;
    this.type = type;
  }
  tick(events){
    //get player
    let player = events.filter(e=>{return e.type=="player"})[0];
    //movement
    let xDir = -1;
    let yDir = -1;
    let rx = player.x - this.x;
    let ry = player.y - this.y;
    if(rx*rx+ry*ry<128*128) this.isActive = true;
    if(this.isActive){
      if(player.y < this.y){
        this.y -= this.speed;
        this.animator.current = "walkUp" + "_" + this.type;
      }
      if(player.y > this.y){
        this.y += this.speed;
        yDir = 1;
        this.animator.current = "walkDown" + "_" + this.type;
      }
      if(player.x < this.x){
        this.x -= this.speed;
        this.animator.current = "walkLeft" + "_" + this.type;
      }
      if(player.x > this.x){
        this.x += this.speed;
        xDir = 1;
        this.animator.current = "walkRight" + "_" + this.type;
      }
    }
    //defaults
    super.tick(xDir,yDir,this.speed,events);
    //drop on death
    if(this.hp<=0){
      //get pool
      let pool = {
        gold:[0,0,0].concat(buildRand("coins",8)),
        item:[15,10,10,10,5,5,5,5,5,5,5,5,5].concat(
          buildRand("keys",15)).concat(
          buildRand("bombs",15)).concat(
          buildRand(0,45))
      }[this.type];
      //randomize and pick
      pool.sort((a,b)=>{return Math.random()-0.5});
      pool = pool.slice(0,8);
      //create and add sprites
      for(let i=0;i<8;i++){
        let pos = [
          [-40,-40],[0,-40],[40,-40],[40,0],
          [40,40],[0,40],[-40,40],[-40,0]
        ][i];
        let item = pool[i]
        if(["coins","keys","bombs"].indexOf(item)!=-1){
          sprites.push(
            new BasicItem(
              this.x + pos[0],this.y+pos[1],item
            )
          );
        } else if(item != 0){
          sprites.push(
            new HealingItem(
              this.x + pos[0],this.y+pos[1],item
            )
          );
        }
      }
    }
  }
  get events() {
    return [
      {type:"enemy"},
      {
        type:"damage",
        ID:this.ID,
        alliance:"enemy",
        power:5*diff[area],
        x:this.x + this.xo,
        y:this.y + this.yo,
        w:this.w,h:this.h,
        cool:100,
      }
    ];
  }
}

class HiddenEnemy extends Enemy {
  constructor(x,y){
    super(x,y,16,16,8,8,false,0.5*diff[area],"enemy",
    0,0.5,new Animator(anims.enemy,"idle" + "_" + area));
    this.speed = 1*diff[area];
    this.r = 0;
  }
  tick(events){
    //get player
    let player = events.filter(e=>{return e.type=="player"})[0];
    //movement
    let xDir = -1;
    let yDir = -1;
    if(player.y < this.y){
      this.y -= this.speed;
      this.animator.current = "walkUp" + "_" + area;
    }
    if(player.y > this.y){
      this.y += this.speed;
      yDir = 1;
      this.animator.current = "walkDown" + "_" + area;
    }
    if(player.x < this.x){
      this.x -= this.speed;
      this.animator.current = "walkLeft" + "_" + area;
    }
    if(player.x > this.x){
      this.x += this.speed;
      xDir = 1;
      this.animator.current = "walkRight" + "_" + area;
    }
    //animation
    this.r += 5;
    //defaults
    super.tick(xDir,yDir,this.speed,events);
    //drops on death
    if(this.hp<=0) sprites.push(new Item(this.x,this.y));
  }
  get events() {
    return [
      {type:"enemy"},
      {
        type:"damage",
        ID:this.ID,
        alliance:"enemy",
        power:5*diff[area],
        x:this.x + this.xo,
        y:this.y + this.yo,
        w:this.w,h:this.h,
        cool:100,
      }
    ];
  }
  draw(ctx,cx,cy,canvas){
    for(let y=0;y<32;y+=5){
      ctx.drawImage(
        canvas.canvas,
        (this.x+Math.sin((y+this.r)/10)*1)-cx,
        (this.y+y)-cy,32,5,
        this.x-cx,(this.y+y)-cy,32,5
      );
    }
    ctx.beginPath();
    ctx.globalAlpha = 0.02;
    ctx.fillStyle = "black";
    ctx.fillRect(this.x-cx,this.y-cy,32,32);
    ctx.globalAlpha = 1;
    ctx.closePath();
  }
}

class DividingEnemy extends Enemy {
  constructor(
    x,y,size,givesCoins=true,type="normal",
    coinVal=5,parentID=undefined
  ){
    super(
      x,y,32*size,20*size,(size-1)*-16,0,
      true,diff[area]*size,"enemy",
      (givesCoins&&size<=1)?coinVal:0,1,
      new Animator(anims.slime,"idle")
    );
    this.speed = 4/size;
    this.size = size;
    this.givesCoins = givesCoins;
    this.coinVal = coinVal;
    this.bounceTimer = Math.random()*100;
    if(parentID){
      this.parentID = parentID;
    } else {
      this.parentID = getID();
    }
    this.spriteType = "divEnemy";
    this.type = type;
  }
  tick(events){
    //bounce timing
    let bMax = 60*this.size;
    this.bounceTimer -= 1;
    if(this.bounceTimer <= 0){
      this.bounceTimer = bMax;
    }
    //movement
    let xDir = -1;
    let yDir = -1;
    if(this.bounceTimer > bMax/4){
      //get player
      let player = events.filter(e=>{return e.type=="player"})[0];
      //move logic
      if(player.y < this.y){
        this.y -= this.speed;
        this.animator.current = "idle";
      }
      if(player.y > this.y){
        this.y += this.speed;
        yDir = 1;
        this.animator.current = "idle";
      }
      if(player.x < this.x){
        this.x -= this.speed;
        this.animator.current = "walkLeft";
      }
      if(player.x > this.x){
        this.x += this.speed;
        xDir = 1;
        this.animator.current = "walkRight";
      }
    }
    //defaults
    super.tick(xDir,yDir,this.speed,events);
    //division
    if(this.hp<=0&&this.size>1){
      let divNum = Array.randElem([2,2,2,2,3,3,4]);
      let angleInc = (Math.PI*2)/divNum;
      let f = this.animator.frame;
      let divDist = Math.sqrt(
        f.width*f.width+f.height*f.height
      )*(this.size/divNum);
      let a = 0;
      let coinsLeft = this.coinVal;
      for(let i=0;i<divNum;i++){
        let avCoins = coinsLeft/(divNum-i);
        let gNum = avCoins-Math.floor(avCoins);
        let eCoin = Math.random()<gNum;
        let tCoins = Math.floor(avCoins)+(eCoin?1:0);
        coinsLeft -= tCoins;
        sprites.push(new DividingEnemy(
          (Math.cos(a)*divDist)+this.x,
          (Math.sin(a)*divDist)+this.y,
          this.size/(divNum*0.75),this.givesCoins,
          this.type,tCoins,this.parentID
        ));
        a += angleInc;
      }
    }
    //drops on death
    if(this.hp<=0&&this.size<=1){
      let others = sprites.filter(s=>{
        return s.spriteType=="divEnemy" &&
          s.ID != this.ID &&
          s.parentID == this.parentID
      });
      if(others.length==0){
        if(this.type == "normal"){
          sprites.push(new AreaChange(this.x,this.y));
        } else if(this.type == "item"){
          sprites.push(new Item(this.x-40,this.y));
          sprites.push(new Item(this.x+40,this.y));
        }
      }
    }
  }
  draw(ctx,cx,cy){
    let s = this.animator.frame;
    let scaled = Canvas.scale(
      s,s.width*this.size,s.height*this.size
    );
    ctx.drawImage(
      scaled,(this.x-cx)-((scaled.width-s.width)/2),
      (this.y-cy)-((scaled.height-s.height)/2)
    );
  }
  get events() {
    return [
      {type:"enemy"},
      {
        type:"damage",
        ID:this.parentID,
        alliance:"enemy",
        power:0.5*diff[area],
        x:this.x + this.xo,
        y:this.y + this.yo,
        w:this.w,h:this.h,
        cool:1,
      }
    ];
  }
}

class AdvancedEnemy extends Enemy {
  constructor(x,y,type,coins){
    super(x,y,32,32,0,0,false,10*diff[area],"enemy",coins,1,new Animator(anims.boss,"idle"));
    this.type = type;
    this.speed = Math.floor(3*diff[area]);
    this.weapon = new Weapon(x,y,40,"enemy",0,1.5*diff[area],2*diff[area],Math.floor(100/diff[area]));
    this.spawnTimer = 0;
    this.arrowCool = 0;
    this.swordReady = 0;
    this.spriteType = "boss";
  }
  tick(events){
    let xDir = -1;
    let yDir = -1;
    let player = events.filter(e=>{return e.type=="player"})[0];
    let angle = Math.angle(
      (player.x+player.w)-(this.x+this.w/2),
      (player.y+player.h)-(this.y+this.h/2)
    )-Math.PI/2;
    //update weapon
    this.weapon.angle = angle;
    this.weapon.x = this.x+this.w/2;
    this.weapon.y = this.y+this.h/2;
    //behavior
    //swing if close
    let rx = player.x - this.x;
    let ry = player.y - this.y;
    let dSq = rx*rx+ry*ry;
    if(dSq<70*70){
      this.swordReady += 1;
      if(this.swordReady > 25){
        this.weapon.swing();
        this.spawnTimer = 25/diff[area];
      } else {
        this.weapon.angle += 3;
      }
    } else {
      this.swordReady = 0;
    }
    //move in if ready to swing
    if(this.weapon.cool==0){
      if(player.y < this.y){
        this.y -= this.speed;
        this.animator.current = "walkUp";
      }
      if(player.y > this.y){
        this.y += this.speed;
        yDir = 1;
        this.animator.current = "walkDown";
      }
      if(player.x < this.x){
        this.x -= this.speed;
        this.animator.current = "walkLeft";
      }
      if(player.x > this.x){
        this.x += this.speed;
        xDir = 1;
        this.animator.current = "walkRight";
      }
    }
    //run away if not ready
    if(this.weapon.cool!=0){
      if(player.y > this.y){
        this.y -= this.speed;
        this.animator.current = "walkUp";
      }
      if(player.y < this.y){
        this.y += this.speed;
        yDir = 1;
        this.animator.current = "walkDown";
      }
      if(player.x > this.x){
        this.x -= this.speed;
        this.animator.current = "walkLeft";
      }
      if(player.x < this.x){
        this.x += this.speed;
        xDir = 1;
        this.animator.current = "walkRight";
      }
    }
    //summon enemies on retreat
    if(this.spawnTimer>0){
      this.spawnTimer -= 1;
    }
    if(this.spawnTimer == 1){
      if(Math.random() > 0.9){
        sprites.push(new RangedEnemy(this.x,this.y,false));
      } else {
        sprites.push(new BasicEnemy(this.x,this.y,false));
      }
    }
    //shoot arrow if far away
    if(this.arrowCool>0){
      this.arrowCool -= 1;
    }
    if(dSq > 300*300 && this.arrowCool<1){
      this.arrowCool = 100/diff[area];
      sprites.push(new Arrow(this.x,this.y,20,"enemy",1*diff[area],angle,1));
    }
    //tick other stuff
    this.weapon.tick();
    super.tick(xDir,yDir,this.speed,events);
    //drop portal on death
    if(this.hp<=0){
      if(this.type == "normal"){
        sprites.push(new AreaChange(this.x,this.y));
      } else if(this.type == "item"){
        sprites.push(new Item(this.x-40,this.y));
        sprites.push(new Item(this.x+40,this.y));
      }
    }
  }
  draw(ctx,cx,cy){
    super.draw(ctx,cx,cy);
    this.weapon.draw(ctx,cx,cy);
  }
  get events(){
    return this.weapon.events;
  }
}
