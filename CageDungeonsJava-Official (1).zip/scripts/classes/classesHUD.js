class MapHud extends HudElem {
  constructor(mx,my){
    let anim = new Animator(anims.map,"n");
    super(
      10+anim.frame.width*mx,
      10+anim.frame.height*my,
      "upper","left",
      500,500,
      anim
    );
    this.mx = mx;
    this.my = my;
    this.pos = {x:0,y:0,w:0,h:0};
    this.m = {x:0,y:0};
    this.hovered = false;
  }
  tick(){
    this.anim.current = map[this.my][this.mx];
    let player = sprites.filter(s=>{return s.spriteType=="player"})[0];
    if(
      Math.floor(
        player.x / (Constants.sizes.roomTSize.x)
      ) == this.mx &&
      Math.floor(
        player.y / (Constants.sizes.roomTSize.y)
      ) == this.my
    ){
      super.tick();
      if(
        visited.filter(c=>{
          return c[0] == this.mx &&
          c[1] == this.my
        }).length == 0
      ){
        visited.push([this.mx,this.my]);
      }
    } else if(
        visited.filter(c=>{
          return c[0] == this.mx &&
          c[1] == this.my
        }).length == 0
      ){
      this.anim.frameNum = 1;
    } else {
      this.anim.frameNum = 0;
    }
    if(
      this.m.x>this.pos.x&&this.m.y>this.pos.y&&
      this.m.x<this.pos.x+this.pos.w&&
      this.m.y<this.pos.y+this.pos.h
    ){
      this.anim.frameNum = 1;
      this.hovered = true;
    } else {
      this.hovered = false;
    }
  }
  checkTP(){
    if(
      this.hovered
    ){
      if(
        Mouse.down&&
        visited.filter(c=>{
          return c[0] == this.mx &&
          c[1] == this.my
        }).length != 0
      ){
        let player = sprites.filter(s=>{return s.spriteType=="player"})[0];
        player.x = this.mx*Constants.sizes.roomTSize.x+Constants.sizes.roomTSize.x/2-Constants.sizes.tileSize.x/2;
        player.y = this.my*Constants.sizes.roomTSize.y+Constants.sizes.tileSize.y*2-Constants.sizes.tileSize.y/2;
      }
    }
  }
  draw(canvas){
    this.pos = super.drawPos(canvas);
    this.m = Mouse.toCanvas(canvas.canvas,Mouse.x,Mouse.y);
    if(map[this.my][this.mx]!="e"){
      super.draw(canvas);
    }
  }
}

class AreaLabel extends HudElem {
  tick() {
    this.anim.current = area;
    super.tick();
  }
}

class ActiveItemDisp extends HudElem {
  tick() {
    this.anim.current = heldItems.activeItem.item.name;
    super.tick();
  }
  draw(canvas){
    let pos = this.drawPos(canvas);
    canvas.ctx.drawImage(
      this.anim.frame,
      pos.x,pos.y,
      pos.w*2,pos.h*2
    );
  }
}

class HudBar extends HudElem {
  constructor(
    x,y,cx,cy,iw,ih,max,val,h,sx,
    fillColor,eColor,bColor,tColor,bWidth,
    id,valMult=1
  ){
    //setup vars
    super(x,y,cx,cy,iw,ih);
    this.max = max;
    this.val = val;
    this.h = h;
    this.sx = sx;
    this.fillColor = fillColor;
    this.eColor = eColor;
    this.bColor = bColor;
    this.bWidth = bWidth;
    this.tColor = tColor;
    this.valMult = valMult;
    this.id = id;
    //setup canvas
    this.can = new Canvas((max*sx)+(bWidth*2),h,{appendChild:()=>{}});
    //update canvas
    this.tick();
  }
  tick(){
    //border
    this.can.width = (this.max*this.sx)+(this.bWidth*2);
    this.can.clear(this.bColor);
    this.can.ctx.beginPath();
    //empty
    this.can.ctx.fillStyle = this.eColor;
    this.can.ctx.fillRect(
      this.bWidth,this.bWidth,
      this.max*this.sx,this.h - (this.bWidth*2)
    );
    //filled
    this.can.ctx.fillStyle = this.fillColor;
    this.can.ctx.fillRect(
      this.bWidth,this.bWidth,
      this.val*this.sx,this.h - (this.bWidth*2)
    );
    this.can.ctx.closePath();
    //text
    this.can.text(
      (this.val*this.valMult)+"/"+(this.max*this.valMult),
      this.tColor,(this.max*this.sx)/2,
      this.bWidth+15
    );
    //update "animator"
    this.anim = {frame:this.can.canvas};
  }
}

class HudText extends HudElem {
  constructor(x,y,cx,cy,iw,ih,textGen,color,fontSize,fontType){
    //setup vars
    super(x,y,cx,cy,iw,ih);
    this.textGen = textGen;
    this.fontSize = fontSize;
    this.font = fontSize+"px "+fontType;
    this.color = color;
    //setup canvas
    this.can = new Canvas(500,500,{appendChild:()=>{}});
    //update canvas
    this.tick();
  }
  tick(){
    //clear
    this.can.ctx.clearRect(0,0,500,500);
    //text
    this.can.text(this.textGen(),this.color,0,this.fontSize,this.font);
    //update "animator"
    this.anim = {frame:this.can.canvas};
  }
}
