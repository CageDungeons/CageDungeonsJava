//Enable strict mode
"use strict";

//utility functions
function overlaps(ax,ay,aw,ah,bx,by,bw,bh){
  return (
    (bx+bw>ax && by+bh>ay) &&
    (bx<ax+aw && by<ay+ah)
  );
}

function touchingTileInd(tiles,types,tx,ty,x,y,w,h){
  let rx = x - tx;
  let ry = y - ty;
  for(let tmy=0;tmy<tiles.length;tmy++){
    for(let tmx=0;tmx<tiles[tmy].length;tmx++){
      if(types.indexOf(tiles[tmy][tmx])>-1){
        if(
          overlaps(
            rx,ry,w,h,
            tmx*Constants.sizes.tileSize.x,
            tmy*Constants.sizes.tileSize.y,
            Constants.sizes.tileSize.x,
            Constants.sizes.tileSize.y
        )){
          return true;
        }
      }
    }
  }
  return false;
}

function touchingTiles(tiles,types,x,y,w,h){
  for(let coll of tiles){
    if (
      Math.abs(
        Math.floor(x / Constants.sizes.roomTSize.x) -
        (coll.x/Constants.sizes.roomTSize.x)
      ) < 10 &&
      Math.abs(
        Math.floor(y / Constants.sizes.roomTSize.y) -
        (coll.y/Constants.sizes.roomTSize.y)
      ) < 10
    ) {
      if(
        touchingTileInd(
          coll.tiles,
          types,
          coll.x,
          coll.y,
          x,y,w,h
        )
      ) {
        return true;
      }
    }
  }
  return false;
}

function collide(
  x,y,w,h,maxSlope,xDir,yDir,colF
){
  let slope = 0;
  while(
    colF(x,y,w,h) &&
    slope <= maxSlope
  ){
    y -= yDir;
    slope += 1;
  }
  if(slope>maxSlope){
    y += slope*yDir;
    slope = 0;
    while(
      colF(x,y,w,h) &&
      slope <= maxSlope
    ){
      x -= xDir;
      slope += 1;
    }
    if(slope>maxSlope){
      x += slope*xDir;
      while(
        colF(x,y,w,h)
      ){
        x -= xDir;
        y -= yDir;
      }
    }
  }
  return [x,y];
}

function drawTiles(tileSet,tiles,x,y,canvas){
  let tile;
  for(let yi=0;yi<tiles.length;yi++){
    for(let xi=0;xi<tiles[yi].length;xi++){
      tile = tileSet[tiles[yi][xi]];
      canvas.ctx.drawImage(
        tile,
        Constants.sizes.tileSize.x*xi+x,
        Constants.sizes.tileSize.y*yi+y,
      );
    }
  }
}

function gen(map,coords,chances){
  let genCoords = coords.slice();
  //shuffle to avoid bias
  genCoords.sort((a,b)=>{return Math.random()-0.5});
  //generate
  for(let loc of genCoords){
    let next = "n";
    if(
      Math.random()<chances.boss && 
      !chances.bossFound
    ){
      next = "b";
      chances.bossFound = true;
    } else if(Math.random()<chances.item){
      next = "i";
      chances.item = -2;
      chances.itemFound = true;
      chances.doorFreq = chances.doorFreq.filter(
        f=>{return f!=4 && f!=3}
      );
      chances.doorFreq.push(3);
    } else if(Math.random()<chances.shop){
      next = "s";
      chances.shop = -2;
    } else if(Math.random()<chances.mini){
      next = "m";
      chances.mini = -0.05;
    }
    map[loc[1]][loc[0]] = next;
  }
  //update
  if(chances.itemFound) {chances.boss += 0.25;}
  chances.item += 0.2;
  chances.shop += 0.25;
  chances.mini += 0.025;
  //change generation
  if(chances.bossFound && chances.itemFound){
    chances.doorFreq.push(0);
    chances.doorFreq.push(0);
    chances.doorFreq.push(0);
    let r = false;
    chances.doorFreq = chances.doorFreq.filter(f=>{
      if(!r&&f!=0){
        r = true;
        return false;
      }
      return true;
    });
  }
}

function buildRoom(map,x,y,rTemps){
  //find room location
  let rx = x*Constants.sizes.roomTSize.x;
  let ry = y*Constants.sizes.roomTSize.y;
  //find number of existing doors into room
  let inDoors = (
    sprites.filter(
      s=>{
        return (s instanceof Door) &&
        s.mx == x && s.my == y
      }
  )).map(d=>{return d.dir});
  inDoors = inDoors.map(d=>{
    return {n:"s",s:"n",e:"w",w:"e"}[d]
  });
  //remove doors into room
  sprites = sprites.filter(s=>{
    return !(s.mx == x && s.my == y)
  });
  //find number of generated tiles
  let genTiles = [];
  if(y>0&&map[y-1][x]!="e"){
    genTiles.push("n");
  }
  if(y<map.length-1&&map[y+1][x]!="e"){
    genTiles.push("s");
  }
  if(x<map[y].length-1&&map[y][x+1]!="e"){
    genTiles.push("e");
  }
  if(x>0&&map[y][x-1]!="e"){
    genTiles.push("w");
  }
  //find number of placed to generate doors
  let spots = [];
  for(let d of ["n","s","e","w"]){
    if(
      inDoors.indexOf(d)==-1 &&
      genTiles.indexOf(d)==-1
    ){
      spots.push(d);
    }
  }
  //find number of doors to try to generate
  let numDoors = Array.randElem(chances.doorFreq);
  //find door locations
  let locs = new Array(spots.length);
  locs.fill(false);
  locs.fill(true,0,numDoors);
  locs.sort((a,b)=>{return Math.random()-0.5;});
  let doors = {};
  for(let dir of ["n","s","e","w"]){
    if(
      inDoors.indexOf(dir)!=-1 ||
      genTiles.indexOf(dir)!=-1
    ){
      doors[dir] = false;
    } else {
      doors[dir] = locs.pop();
    }
  }
  //find enterances
  let enters = Object.assign({},doors);
  for(let d of inDoors){
    enters[d] = true;
  }
  //get room template
  let temp = Array.randElem(rTemps[map[y][x]]);
  //get encounter
  let enc = temp[1];
  //duplicate template tiles
  let tempD = [];
  for(let row of temp[0]){
    tempD.push(row.slice());
  }
  //add enterences
  if(enters.n && y>0){
    tempD[0][
      Math.floor(tempD[0].length/2)
    ] = "dv";
  }
  if(enters.s && y<map.length-1){
    tempD[
      tempD.length-1
    ][
      Math.floor(tempD[0].length/2)
    ] = "dv";
  }
  if(enters.e && x<map[0].length-1){
    tempD[
      Math.floor(tempD.length/2)
    ][
      tempD[0].length-1
    ] = "de";
    tempD[
      Math.floor(tempD.length/2)-1
    ][
      tempD[0].length-1
    ] = inDoors.indexOf("e")?"dne":"wn";
  }
  if(enters.w && x>0){
    tempD[
      Math.floor(tempD.length/2)
    ][0] = "dw";
    tempD[
      Math.floor(tempD.length/2)-1
    ][0] = inDoors.indexOf("w")?"dne":"wn";
  }
  //genrate pathfinding nodes
  let prev = null;
  let pRow = [];
  for(let yn=0;yn<tempD.length;yn++){
    for(let xn=0;xn<tempD[yn].length;xn++){
      //generate
      let node = new PathNode(
        (xn*Constants.sizes.tileSize.x)+rx+Constants.sizes.tileSize.x/2,
        (yn*Constants.sizes.tileSize.y)+ry+Constants.sizes.tileSize.y/2,
        tempD[yn][xn],x+","+y
      );
      //link W
      if(prev&&xn>0){
        node.link(prev);
      }
      prev = node;
      //link S
      if(pRow[xn]){
        node.link(pRow[xn]);
      }
      pRow[xn] = node;
      //link across rooms
      if(
        ["dv","de","dw"].indexOf(node.tile)>-1
      ){
        let oNodes = pathNodes.filter(n=>{return n.id!=node.id});
        oNodes = oNodes.filter(n=>{return ["dv","de","dw"].indexOf(n.tile)>-1});
        oNodes.sort((a,b)=>{return (a.x*a.x+a.y*a.y)-(b.x*b.x+b.y*b.y)});
        if(oNodes[0]){
          node.link(oNodes[0]);
        }
      }
      //add to node list
      pathNodes.push(node);
    }
  }
  //add detailing
  enhanceRoom(tempD,[
    ["wn","wnd",0.01],
    ["wn","wnd2",0.01],
    ["g","gd",0.01],
    ["pt","ptd",0.01],
  ]);
  //add to room tiles
  rooms.push({
    x: rx,
    y: ry,
    tiles: tempD
  });
  //get encounter template
  let eTempD = enc();
  //position sprites
  for(let e of eTempD){
    e.x += x*Constants.sizes.roomTSize.x;
    e.y += y*Constants.sizes.roomTSize.y;
  }
  //add
  sprites = sprites.concat(eTempD);
  //generate rooms with doors
  let genCs = [];
  if(doors.n && y > 0){
    genCs.push([x,y-1]);
  }
  if(doors.s && y < map.length-1){
    genCs.push([x,y+1]);
  }
  if(doors.e && x < map[y].length-1){
    genCs.push([x+1,y]);
  }
  if(doors.w && x > 0){
    genCs.push([x-1,y]);
  }
  gen(map,genCs,chances);
  //create doors
  if(doors.n && y > 0){
    sprites.push(new Door(
      rx+Constants.sizes.roomTSize.x/2-Constants.sizes.tileSize.x/2,ry,
      x,y-1,"n"
    ));
  }
  if(doors.s && y < map.length-1){
    sprites.push(new Door(
      rx+Constants.sizes.roomTSize.x/2-Constants.sizes.tileSize.x/2,
      ry+Constants.sizes.roomTSize.y-Constants.sizes.tileSize.y,
      x,y+1,"s"
    ));
  }
  if(doors.e && x < map[y].length-1){
    sprites.push(new Door(
      rx+Constants.sizes.roomTSize.x-Constants.sizes.tileSize.x,
      ry+Constants.sizes.roomTSize.y/2-Constants.sizes.tileSize.y/2,
      x+1,y,"e"
    ));
  }
  if(doors.w && x > 0){
    sprites.push(new Door(
      rx,ry+Constants.sizes.roomTSize.y/2-Constants.sizes.tileSize.y/2,
      x-1,y,"w"
    ));
  }
}

function enhanceRoom(tiles,rules){
  for(let y=0;y<tiles.length;y++){
    for(let x=0;x<tiles[y].length;x++){
      for(let rule of rules){
        if(
          rule[0] == tiles[y][x] &&
          Math.random() < rule[2]
        ){
          tiles[y][x] = rule[1];
        }
      }
    }
  }
}

function buildTileset(ss,b,dne,deu,dwu){
  return {
    wn:ss[0],
    ws:ss[1],
    we:ss[2],
    ww:ss[3],
    cl:ss[4],
    cr:ss[5],
    g:ss[6],
    dh:ss[7],
    dv:ss[11],
    de:ss[12],
    dw:ss[13],
    p:ss[14],
    b:b,
    pt:ss[15],
    wnd:ss[16],
    wnd2:ss[17],
    gd:ss[18],
    ptd:ss[19],
    dne:dne,
    deu:deu,
    dwu:dwu
  };
}

function remap(action){
  controls[action] = prompt("Press the new key and then press Enter");
  let text = document.getElementById(action);
  text.childNodes[0].nodeValue = (controls[action].slice()).toUpperCase();
}

function buildAnimations(baseSet,variants){
  let out = {};
  //loop over variants
  let vNum = 0;
  for(let v of variants){
    //build conversion table (and count frames)
    let convTable = {};
    let totalFrames = [];
    for(let anim of Object.keys(baseSet)){
      totalFrames = totalFrames.concat(baseSet[anim].frames);
      convTable[anim] = anim + "_" + v;
    }
    let frameFilter = [];
    for(let f of totalFrames){
      if(frameFilter.indexOf(f)==-1){
        frameFilter.push(f);
      }
    }
    totalFrames = frameFilter.length;
    //start converting
    for(let anim of Object.keys(baseSet)){
      //create ofset frames
      let frames = baseSet[anim].frames;
      frames = frames.map(
        fn=>{return fn+(vNum*totalFrames)}
      );
      //build animation
      out[convTable[anim]] = {
        frames:frames,
        fpt:baseSet[anim].fpt,
        next:convTable[baseSet[anim].next]
      };
    }
    vNum += 1;
  }
  return out;
}

function mapAnims(anims,files){
  //copy anims
  let animsC = Object.assign({},anims);
  //find file length
  let fSize = files[0].length;
  //loop over anims
  for(let anim of Object.keys(animsC)){
    //extract and convert
    let fs = animsC[anim].frames;
    fs = fs.map(f=>{
      return files[Math.floor(f/fSize)][f%fSize];
    });
    animsC[anim].frames = fs;
  }
  //return
  return animsC;
}

function setDiff(n){
  if(n=="custom"){
    do {
      n = prompt("Enter custom difficulty");
      n = (n-1)+1;
    } while(Number.isNaN(n));
  }
  for(let a of Object.keys(diff)){
    if(a != "old"){
      diff[a] /= diff.old;
      diff[a] *= n;
    }
  }

  diff.old = n;
}

function buildRand(e,l){
  return new Array(l).fill(e);
}
