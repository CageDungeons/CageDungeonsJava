//Enable strict mode
"use strict";

//create tilesets
const tilesets = {
  "Start": buildTileset(ss.castleTiles,ss.castleTiles[14],ss.castleTiles[7],ss.castleTiles[12],ss.castleTiles[13]),
  "Gates": buildTileset(ss.castleTiles,ss.castleTiles[14],ss.castleTiles[7],ss.castleTiles[12],ss.castleTiles[13]),
  "Ash Flats": buildTileset(ss.flatsTiles,ss.castleTiles[14],ss.flatsTiles[7],ss.flatsTiles[12],ss.flatsTiles[13]),
  "Bone Shore": buildTileset(ss.shoreTiles,ss.castleTiles[14],ss.shoreTiles[7],ss.shoreTiles[12],ss.shoreTiles[13]),
  "Cinder Wastes": buildTileset(ss.wastesTiles,ss.castleTiles[14],ss.wastesTiles[0],ss.wastesTiles[12],ss.wastesTiles[13]),
  "Precipice": buildTileset(ss.precipiceTiles,ss.precipiceTiles[14],ss.precipiceTiles[0],ss.precipiceTiles[12],ss.precipiceTiles[13]),
  "Fire Sea": buildTileset(ss.seaTiles,ss.seaTiles[14],ss.seaTiles[0],ss.seaTiles[6],ss.seaTiles[6]),
  "Shadow Caverns": buildTileset(ss.cavernsTiles,ss.castleTiles[14],ss.cavernsTiles[7],ss.cavernsTiles[12],ss.cavernsTiles[13]),
  "Magma Pools": buildTileset(ss.poolsTiles,ss.castleTiles[14],ss.poolsTiles[7],ss.poolsTiles[12],ss.poolsTiles[13]),
  "The Castle": buildTileset(ss.castleTiles,ss.castleTiles[14],ss.castleTiles[7],ss.castleTiles[12],ss.castleTiles[13])
};

//base stats
heldItems.addItem({
  name:"Base Stats",
  speed:{op:"+",val:8},
  maxHealth:{op:"+",val:55},
  mSpeed:{op:"+",val:1},
  mDam:{op:"+",val:2},
  mRange:{op:"+",val:1},
  rSpeed:{op:"+",val:1},
  rDam:{op:"+",val:1},
  rRange:{op:"+",val:1},
  priority:0.5,
});

//map
let map = [
  ["e","e","e","e","e","e","e","e","e"],
  ["e","e","e","e","e","e","e","e","e"],
  ["e","e","e","e","e","e","e","e","e"],
  ["e","e","e","e","e","e","e","e","e"],
  ["e","e","e","e","e","e","e","e","e"],
  ["e","e","e","e","e","e","e","e","e"],
  ["e","e","e","e","e","e","e","e","e"],
  ["e","e","e","e","e","e","e","e","e"],
  ["e","e","e","e","e","e","e","e","e"],
];
let visited = [];

//area transition map
const aTM = {
  "Start":["Gates"],
  "Gates":["Ash Flats","Bone Shore"],
  "Ash Flats":["Cinder Wastes","Precipice"],
  "Bone Shore":["Fire Sea","Precipice"],
  "Cinder Wastes":["Shadow Caverns","Magma Pools"],
  "Precipice":["Shadow Caverns","Magma Pools"],
  "Fire Sea":["Shadow Caverns","Magma Pools"],
  "Shadow Caverns":["The Castle"],
  "Magma Pools":["The Castle"],
  "The Castle":["win"]
};
const diff = {
  "Gates":1,
  "Ash Flats":1.5,
  "Bone Shore":1.5,
  "Cinder Wastes":2,
  "Precipice":2,
  "Fire Sea":2,
  "Shadow Caverns":2.5,
  "Magma Pools":2.5,
  "The Castle":2.5,
  old:1,
}
let area = "Start";

//player start location
const mapCenter = {
  x:Math.floor(map[0].length/2),
  y:Math.floor(map.length/2)
};
const playerStart = {
  x:Constants.sizes.roomTSize.x*mapCenter.x+
  (Constants.sizes.roomTSize.x/2)-(Constants.sizes.tileSize.x/2),
  y:Constants.sizes.roomTSize.y*mapCenter.y+
  (Constants.sizes.roomTSize.y/2)-(Constants.sizes.tileSize.y/2)
};

//generation chances
let chances = {
  boss: 0,
  item: 0,
  shop: 0,
  mini: 0,
  doorFreq: [1,1,1,1,1,2,2,2,2,3,3,4]
};

//generated room tiles
let rooms = [
  {
    tiles: [
      ["ww","wn","wn","wn","wn","wn","we"],
      ["ww","g", "g", "g", "g", "g", "we"],
      ["ww","g", "g", "g", "g", "g", "we"],
      ["ww","g", "g", "g", "g", "g", "we"],
      ["ww","g", "g", "g", "g", "g", "we"],
      ["ww","g", "g", "g", "g", "g", "we"],
      ["cl","ws","ws","ws","ws","ws","cr"]
    ],
    x:0,
    y:0
  }
];

//HUD elements
const hud = [
  //health bar
   new HudBar(
    200,50,"upper","left",500,500,
    100,50,25,2,"#66FF66","red","#A6A6A6",
    "black",2,"health"
  ),
  //area
  new AreaLabel(
    200,15,"upper","left",500,500,
    new Animator(anims.areaLabel,area)
  ),
  //active item
  new ActiveItemDisp(
    10,-110,"lower","left",500,500,
    new Animator(anims.item,"Minecraft")
  ),
  new HudBar(
    10,-35,"lower","left",500,500,
    100,50,25,2,"red","black","gray",
    "white",2,"charge",0.1
  ),
  //shield bar
  new HudBar(
    10,-150,"lower","left",200,200,
    100,90,25,2,"#367a8c","red","white",
    "white",2,"health.2"
  ),
  //new HudBar(),
  //coins
  new HudElem(
    -100,20,"upper","right",500,500,
    new Animator(anims.basicItem,"coins")
  ),
  new HudText(
    -50,20,"upper","right",500,500,
    ()=>{return heldItems.basicItems.coins},
    "gold",20,"serif"
  ),
  //keys
  new HudElem(
    -100,60,"upper","right",500,500,
    new Animator(anims.basicItem,"keys")
  ),
  new HudText(
    -50,60,"upper","right",500,500,
    ()=>{return heldItems.basicItems.keys},
    "silver",20,"serif"
  ),
  //bombs
  new HudElem(
    -100,100,"upper","right",500,500,
    new Animator(anims.basicItem,"bombs")
  ),
  new HudText(
    -50,100,"upper","right",500,500,
    ()=>{return heldItems.basicItems.bombs},
    "orange",20,"serif"
  )
];

   //generate HUD map
for(let y=0;y<map.length;y++){
  for(let x=0;x<map[y].length;x++){
    hud.push(new MapHud(x,y));
  }
}

//pathfinding nodes
let pathNodes = [];

//sprite array
let sprites = [
  new Player(
    Constants.sizes.tileSize.x,
    Constants.sizes.tileSize.y
  ),
  new AreaChange(
    Constants.sizes.tileSize.x*3,
    Constants.sizes.tileSize.y*3
  ),
];

//actions object
const actions = {
  moveN:false,
  moveS:false,
  moveE:false,
  moveW:false,
  slow:false,
  interact:false,
  bomb:false,
  useActive:false,
  mAttack:false,
  rAttack:false,
  tap:false,
  selW:"mAttack",
  swapW:false,
};

//key-action decoder
const controls = {
  moveN:"w",
  moveS:"s",
  moveE:"a",
  moveW:"d",
  slow:" ",
  interact:"q",
  bomb:"f",
  useActive:"r",
  mAttack:"j",
  rAttack:"k",
  swapW:"e"
}

//tap listener
window.addEventListener("mousedown",e=>{
  actions.tap = true;
  for(let e of hud){
    if(e instanceof MapHud){
      e.checkTP();
    }
  }
},false);

//swap listener
window.addEventListener("keydown",e=>{
  if(e.key == controls.swapW){
    if(actions.selW == "mAttack"){
      actions.selW = "rAttack";
    } else if(actions.selW == "rAttack"){
      actions.selW = "mAttack";
    }
    let player = sprites.filter(
      s=>{return s.spriteType == "player"}
    )[0];
    player.weapon.animator.anims = anims[{
      rAttack:"bow",mAttack:"sword"
    }[actions.selW]];
    actions.swapW = false;
  }
},false);

//difficulty listener
document.getElementById("diffSel").addEventListener("change",e=>{
  for(let option of Array.from(document.getElementById("diffSel").options)){
    if(option.selected){
      setDiff(option.value);
    }
  }
},false);
for(let option of Array.from(document.getElementById("diffSel").options)){
  if(option.selected){
    setDiff(option.value);
  }
}

//create canvas
const canvas = new Canvas(500,500);

//create screenshake
const shake = new ScreenShake();

//camera ofsets
let camX = 0;
let camY = 0;

//event que
let eventQue = [];

//run progress
let progress = "not started";

//main loop
function run() {try{
  progress = "clearing";
  //clear and fullscreen canvas
  canvas.fullScreen();
  canvas.clear("black");

  progress = "actions";

  //update actions
  for(let action of Object.keys(controls)){
    if(["swapW"].indexOf(action)==-1){
      actions[action] = Keys[controls[action]];
    }
  }
  if(actions.tap){
    actions[actions.selW] = true;
    actions.tap = false;
  }

  progress = "events";

  //get events
  let events = eventQue.slice();
  eventQue = [];
  sprites.forEach(
    sprite => {
      events = events.concat(sprite.events);
    }
  );

  progress = "tick sprites";

  //tick sprites
  let won = false;
  sprites.forEach(
    sprite => {
      if(
        sprite.x-camX>-500&&sprite.x-camX<canvas.width+500&&
        sprite.y-camY>-500&&sprite.y-camY<canvas.height+500&&
        !won
      ){
        sprite.tick(events);
        //check for win
        if(area=="win"){
          won = true;
        }
      }
    }
  );
  if(won){
    alert(`
      You won!
      ...but the only thing here is a sign:
      "I was too lazy to put anything here, but congrats on winning anyway!"
    `);
    return;
  }

  progress = "post-tick sprites";

  //order sprites by y
  sprites.sort((a,b)=>{return a.y-b.y});

  //get player
  let player = sprites.filter(s=>{return s.spriteType=="player";})[0];

  //check for death
  if(!player) return;

  progress = "tick hud";

  //tick HUD
  for(let element of hud){
    element.tick();
  }
  let healthBar = hud.filter(e=>{return e.id=="health"})[0];
  healthBar.max = heldItems.stats.maxHealth;
  healthBar.val = sprites.filter(s=>{return s.spriteType=="player";})[0].hp;
  let chargeBar = hud.filter(e=>{return e.id=="charge"})[0];
  chargeBar.max = heldItems.activeItem.item.charges*10;
  chargeBar.val = heldItems.activeItem.charges*10;

  progress = "camera";

  //tick shake
  shake.tick(events);
  
  //calculate camera ofset
  camX = (player.x-canvas.width/2)+16+shake.shake.x;
  camY = (player.y-canvas.height/2)+16+shake.shake.y;

  progress = "draw room";

  //draw rooms
  let rx,ry;
  for(let room of rooms){
    rx = room.x-camX;
    ry = room.y-camY;
    if(
      rx<canvas.width &&
      ry<canvas.height &&
      rx+Constants.sizes.roomTSize.x>0&&
      ry+Constants.sizes.roomTSize.y>0
    ){
      drawTiles(
        tilesets[area],
        room.tiles,
        rx,ry,
        canvas
      );
    }
  }

  progress = "draw sprites";

  //draw sprites
  sprites.forEach(
    sprite => {
      sprite.draw(
        canvas.ctx,
        camX,
        camY,
        canvas
      );
    }
  );

  /*/draw path nodes(debug)
  for(let n of pathNodes){
    n.draw(canvas.ctx,camX,camY);
  }/**/

  progress = "draw hud";

  //draw HUD
  for(let element of hud){
    element.draw(canvas);
  }

  //loop
  window.requestAnimationFrame(run);
}catch(e){
  function stringObj(o,d=0){
    let r = "{";
    for(let p of Object.keys(o)){
      r += p;
      r += ":";
      if(typeof o[p] == typeof {} && o[p]!=null){
        r += stringObj(o[p],d+1);
      } else {
        r += o[p];
      }
      r += ",";
    }
    return r + "}";
  }
  alert("An error occured and the game crashed");
  document.getElementById("errors").appendChild(
    document.createTextNode(
      "An eror occured and the game crashed:"+e+
      ", in section "+progress+
      ", sprite dump: "+stringObj(sprites)
    )
  );
  null.f;
}}

run();
