//Enable strict mode
"use strict";

//load and create spritesheets
const ss = {
  //sprites
  player: Animator.spriteSheet(
    load.out["assets/sprites/player.png"],
    10
  ),
  enemies: Animator.spriteSheet(
    load.out["assets/sprites/enemies.png"],
    36
  ),
  boss: Animator.spriteSheet(
    load.out["assets/sprites/boss.png"],
    10
  ),
  slime: Animator.spriteSheet(
    load.out["assets/sprites/slime.png"],
    6
  ),
  chestEnemy: Animator.spriteSheet(
    load.out["assets/sprites/chestEnemy.png"],
    18
  ),
  //tilesets
  castleTiles: Animator.spriteSheet(
    load.out["assets/tiles/castleTiles.png"],
    20
  ),
  shoreTiles: Animator.spriteSheet(
    load.out["assets/tiles/shoreTiles.png"],
    20
  ),
  flatsTiles: Animator.spriteSheet(
    load.out["assets/tiles/flatsTiles.png"],
    20
  ),
  poolsTiles: Animator.spriteSheet(
    load.out["assets/tiles/poolsTiles.png"],
    20
  ),
  wastesTiles: Animator.spriteSheet(
    load.out["assets/tiles/wastesTiles.png"],
    20
  ),
  seaTiles: Animator.spriteSheet(
    load.out["assets/tiles/seaTiles.png"],
    20
  ),
  precipiceTiles: Animator.spriteSheet(
    load.out["assets/tiles/precipiceTiles.png"],
    20
  ),
  cavernsTiles: Animator.spriteSheet(
    load.out["assets/tiles/cavernsTiles.png"],
    20
  ),
  //misc
  portal: Animator.spriteSheet(
    load.out["assets/sprites/portal.png"],
    4
  ),
  items: Animator.spriteSheet(
    load.out["assets/sprites/items.png"],
    33
  ),
  healingItems: Animator.spriteSheet(
    load.out["assets/sprites/healingItems.png"],
    3
  ),
  chest: Animator.spriteSheet(
    load.out["assets/sprites/chest.png"],
    2
  ),
  rock: Animator.spriteSheet(
    load.out["assets/sprites/rock.png"],
    1
  ),
  bomb: Animator.spriteSheet(
    load.out["assets/sprites/bomb.png"],
    2
  ),
  sword: Animator.spriteSheet(
    load.out["assets/sprites/sword.png"],
    2
  ),
  arrow: Animator.spriteSheet(
    load.out["assets/sprites/arrow.png"],
    1
  ),
  lightning: Animator.spriteSheet(
    load.out["assets/sprites/lightning.png"],
    1
  ),
  //HUD
  areaLabels: (
      Animator.spriteSheet(
        load.out["assets/hud/areaLabels.png"],
        10
      )
    ).map(
      f=>{return Canvas.scale(f,128,32)}
    ),
  map: (
      Animator.spriteSheet(
        load.out["assets/hud/mapIcons.png"],
        11
      )
    ).map(
      f=>{return Canvas.scale(f,20,20)}
    ),
  basicItems: Animator.spriteSheet(
    load.out["assets/hud/basicItems.png"],
    3
  )
};

for(let a of ["castle","shore","flats","pools","wastes","sea","precipice","caverns"]){
  ss[a+"Tiles"] = ss[a+"Tiles"].map(i=>{
    return Canvas.scale(i,
      Constants.sizes.tileSize.x,
      Constants.sizes.tileSize.y
    );
  })
}

//create animations
const anims = {
  player: {
    idle: {
      frames: [ss.player[8],ss.player[9]],
      fpt: 10,
      next: "idle"
    },
    walkUp: {
      frames: [ss.player[2],ss.player[3]],
      fpt: 10,
      next: "idle"
    },
    walkDown: {
      frames: [ss.player[6],ss.player[7]],
      fpt: 10,
      next: "idle",
    },
    walkLeft: {
      frames: [ss.player[4],ss.player[5]],
      fpt: 10,
      next: "idle"
    },
    walkRight: {
      frames: [ss.player[0],ss.player[1]],
      fpt: 10,
      next: "idle"
    }
  },
  enemy: mapAnims(
    buildAnimations(
      {
        "idle": {
          frames: [2,3],
          fpt: 10,
          next: "idle"
        },
        "walkUp": {
          frames: [2,3],
          fpt: 10,
          next: "idle"
        },
        "walkDown": {
          frames: [2,3],
          fpt: 10,
          next: "idle"
        },
        "walkLeft": {
          frames: [2,3],
          fpt: 10,
          next: "idle"
        },
        "walkRight": {
          frames: [0,1],
          fpt: 10,
          next: "idle"
        }
      },
      Constants.areas
    ),
    [
      ss.enemies
    ]
  ),
  boss: {
    idle: {
      frames: [ss.boss[8],ss.boss[9]],
      fpt: 10,
      next: "idle"
    },
    walkUp: {
      frames: [ss.boss[2],ss.boss[3]],
      fpt: 10,
      next: "idle"
    },
    walkDown: {
      frames: [ss.boss[6],ss.boss[7]],
      fpt: 10,
      next: "idle",
    },
    walkLeft: {
      frames: [ss.boss[4],ss.boss[5]],
      fpt: 10,
      next: "idle"
    },
    walkRight: {
      frames: [ss.boss[0],ss.boss[1]],
      fpt: 10,
      next: "idle"
    }
  },
  slime: {
    idle: {
      frames: [ss.slime[0],ss.slime[1]],
      fpt: 10,
      next: "idle"
    },
    walkLeft: {
      frames: [ss.slime[4],ss.slime[5]],
      fpt: 10,
      next: "idle"
    },
    walkRight: {
      frames: [ss.slime[2],ss.slime[3]],
      fpt: 10,
      next: "idle"
    }
  },
  chestEnemy: mapAnims(
    buildAnimations(
      {
        "idle": {
          frames: [0,0,0,0,0,1,2,3],
          fpt: 100,
          next: "idle"
        },
        "walkUp": {
          frames: [4,5],
          fpt: 10,
          next: "idle"
        },
        "walkDown": {
          frames: [4,6],
          fpt: 10,
          next: "idle"
        },
        "walkLeft": {
          frames: [4,8],
          fpt: 10,
          next: "idle"
        },
        "walkRight": {
          frames: [4,7],
          fpt: 10,
          next: "idle"
        }
      },
      ["item","gold"]
    ),
    [
      ss.chestEnemy
    ]
  ),
  door: mapAnims(
    buildAnimations(
      {
        "n": {
          frames: [0],
          fpt: 10,
          next: "n"
        },
        "s": {
          frames: [1],
          fpt: 10,
          next: "s"
        },
        "e": {
          frames: [2],
          fpt: 10,
          next: "e"
        },
        "w": {
          frames: [3],
          fpt: 10,
          next: "w"
        }
      },
      Constants.areas
    ),
    [
      ss.castleTiles,ss.flatsTiles,ss.shoreTiles,
      ss.wastesTiles,ss.precipiceTiles,ss.seaTiles,
      ss.cavernsTiles,ss.poolsTiles,ss.castleTiles
    ].map(f=>{return f.slice(7,11)})
  ),
  doorExt: mapAnims(
    buildAnimations(
      {
        "e": {
          frames: [0],
          fpt: 10,
          next: "e"
        },
        "w": {
          frames: [1],
          fpt: 10,
          next: "w"
        }
      },
      Constants.areas
    ),
    [
      ss.castleTiles,ss.flatsTiles,ss.shoreTiles,
      ss.wastesTiles,ss.precipiceTiles,ss.seaTiles,
      ss.cavernsTiles,ss.poolsTiles,ss.castleTiles
    ].map(f=>{return f.slice(2,4)})
  ),
  map: {
    n: {
      frames: [ss.map[1],ss.map[2]],
      fpt: 10,
      next: "n"
    },
    m: {
      frames: [ss.map[9],ss.map[10]],
      fpt: 10,
      next: "m"
    },
    b: {
      frames: [ss.map[3],ss.map[4]],
      fpt: 10,
      next: "b"
    },
    i: {
      frames: [ss.map[5],ss.map[6]],
      fpt: 10,
      next: "i"
    },
    s: {
      frames: [ss.map[7],ss.map[8]],
      fpt: 10,
      next: "s"
    },
    e: {
      frames: [ss.map[0],ss.map[0]],
      fpt: 10,
      next: "e"
    },
    f: {
      frames: [ss.map[1],ss.map[2]],
      fpt: 10,
      next: "f"
    }
  },
  areaChange: {
    idle: {
      frames: [
        ss.portal[0],ss.portal[1],
        ss.portal[2],ss.portal[3]
      ],
      fpt: 10,
      next: "idle"
    }
  },
  areaLabel: {
    "Start": {
      frames: [ss.areaLabels[0]],
      fpt: 10,
      next: "Start"
    },
    "Gates":{
      frames: [ss.areaLabels[1]],
      fpt: 10,
      next: "Gates"
    },
    "Ash Flats":{
      frames: [ss.areaLabels[2]],
      fpt: 10,
      next: "Ash Flats"
    },
    "Bone Shore":{
      frames: [ss.areaLabels[3]],
      fpt: 10,
      next: "Bone Shore"
    },
    "Cinder Wastes":{
      frames: [ss.areaLabels[4]],
      fpt: 10,
      next: "Cinder Wastes"
    },
    "Precipice":{
      frames: [ss.areaLabels[5]],
      fpt: 10,
      next: "Precipice"
    },
    "Fire Sea":{
      frames: [ss.areaLabels[6]],
      fpt: 10,
      next: "Fire Sea"
    },
    "Shadow Caverns":{
      frames: [ss.areaLabels[7]],
      fpt: 10,
      next: "Shadow Caverns"
    },
    "Magma Pools":{
      frames: [ss.areaLabels[8]],
      fpt: 10,
      next: "Magma Pools"
    },
    "The Castle":{
      frames: [ss.areaLabels[9]],
      fpt: 10,
      next: "The Castle"
    },
  },
  item: {
    "Multiplier":{
      frames:[ss.items[0]],
      fpt:10,
      next:"Multiplier"
    },
    "Turmoil":{
      frames:[ss.items[5]],
      fpt:10,
      next:"Turmoil"
    },
    "Laser":{
      frames:[ss.items[7]],
      fpt:10,
      next:"Laser"
    },
    "Minecraft":{
      frames:[ss.items[6]],
      fpt:10,
      next:"Minecraft"
    },
    "Glass Heart":{
      frames:[ss.items[1]],
      fpt:10,
      next:"Glass Heart"
    },
    "Sanic Shoes":{
      frames:[ss.items[13]],
      fpt:10,
      next:"Sanic Shoes"
    },
    "Melee Mastery":{
      frames:[ss.items[14]],
      fpt:10,
      next:"Melee Mastery"
    },
    "Ranged Mastery":{
      frames:[ss.items[16]],
      fpt:10,
      next:"Ranged Mastery"
    },
    "Sniper":{
      frames:[ss.items[8]],
      fpt:10,
      next:"Sniper"
    },
    "Lightning Rod":{
      frames:[ss.items[2]],
      fpt:10,
      next:"Lightning Rod"
    },
    "Speedrunning Serum":{
      frames:[ss.items[12]],
      fpt:10,
      next:"Speedrunning Serum"
    },
    "Polish":{
      frames:[ss.items[3]],
      fpt:10,
      next:"Polish"
    },
    "Claymore":{
      frames:[ss.items[24]],
      fpt:10,
      next:"Claymore"
    },
    "Back to Basics":{
      frames:[ss.items[22]],
      fpt:10,
      next:"Back to Basics"
    },
    "Phylactery":{
      frames:[ss.items[25]],
      fpt:10,
      next:"Phylactery"
    },
    "Winged shoes":{
      frames:[Canvas.crop(Canvas.scale(ss.items[4],64,64),16,16,32,32)],
      fpt:10,
      next:"Winged shoes"
    },
    "Demon Horn":{
      frames:[ss.items[26]],
      fpt:10,
      next:"Demon Horn"
    },
    "Poker":{
      frames:[ss.items[11]],
      fpt:10,
      next:"Poker"
    },
    "Precision Arrows":{
      frames:[ss.items[15]],
      fpt:10,
      next:"Precision Arrows"
    },
    "Breastplate":{
      frames:[ss.items[27]],
      fpt:10,
      next:"Breastplate"
    },
    "Speed Charm":{
      frames:[Canvas.crop(Canvas.scale(ss.items[21],64,64),16,16,32,32)],
      fpt:10,
      next:"Speed Charm"
    },
    "Health Charm":{
      frames:[ss.items[10]],
      fpt:10,
      next:"Health Charm"
    },
    "Quick Cut Charm":{
      frames:[ss.items[18]],
      fpt:10,
      next:"Quick Cut Charm"
    },
    "Cleaving Charm":{
      frames:[ss.items[17]],
      fpt:10,
      next:"Cleaving Charm"
    },
    "Longsword Charm":{
      frames:[ss.items[20]],
      fpt:10,
      next:"Longsword Charm"
    },
    "Fastflight Charm":{
      frames:[ss.items[19]],
      fpt:10,
      next:"Fastflight Charm"
    },
    "Piercing Charm":{
      frames:[ss.items[9]],
      fpt:10,
      next:"Piercing Charm"
    },
    "Longbow Charm":{
      frames:[ss.items[23]],
      fpt:10,
      next:"Longbow Charm"
    },
    "Steroids":{
      frames:[ss.items[28]],
      fpt:10,
      next:"Steroids"
    },
    "Magnet":{
      frames:[ss.items[29]],
      fpt:10,
      next:"Magnet"
    },
    "Pile of Dust":{
      frames:[ss.items[30]],
      fpt:10,
      next:"Pile of Dust"
    },
    "POW Block":{
      frames:[ss.items[31]],
      fpt:10,
      next:"POW Block"
    },
    "Chestception!":{
      frames:[ss.items[32]],
      fpt:10,
      next:"Chestception!"
    },
  },
  basicItem: {
    "coins": {
      frames: [ss.basicItems[0]],
      fpt:10,
      next:"coins"
    },
    "keys": {
      frames: [ss.basicItems[1]],
      fpt:10,
      next:"keys"
    },
    "bombs": {
      frames: [ss.basicItems[2]],
      fpt:10,
      next:"bombs"
    }
  },
  healingItem: {
    5:{
      frames:[ss.healingItems[2]],
      fpt:10,
      next:5
    },
    10:{
      frames:[ss.healingItems[1]],
      fpt:10,
      next:10
    },
    15:{
      frames:[ss.healingItems[0]],
      fpt:10,
      next:15
    }
  },
  chest: {
    gold: {
      frames:[ss.chest[1]],
      fpt:10,
      next:"gold"
    },
    item: {
      frames:[ss.chest[0]],
      fpt:10,
      next:"item"
    }
  },
  rock: {
    idle: {
      frames:[ss.rock[0]],
      fpt:10,
      next:"idle"
    }
  },
  bomb: {
    idle: {
      frames: [ss.bomb[0]],
      fpt:10,
      next:"idle"
    },
    exploding: {
      frames: [ss.bomb[1]],
      fpt:10,
      next:"exploding"
    }
  },
  sword: {
    held: {
      frames: [ss.sword[0]],
      fpt: 10,
      next: "held"
    },
    swinging: {
      frames: [ss.sword[1]],
      fpt: 10,
      next: "swinging"
    }
  },
  bow: {
    held: {
      frames: [Canvas.rotate(ss.items[23],Math.PI*1.75)],
      fpt: 10,
      next: "held"
    },
    swinging: {
      frames: [Canvas.rotate(ss.items[23],Math.PI*1.75)],
      fpt: 10,
      next: "swinging"
    }
  },
  arrow: {
    shot: {
      frames: [ss.arrow[0]],
      fpt:10,
      next:"shot"
    }
  },
  lightning: {
    shocking: {
      frames: [ss.lightning[0]],
      fpt:10,
      next:"shocking"
    }
  },
  upperLeft: {
    idle: {
      frames:[load.out["assets/sprites/upperLeft.png"]],
      fpt:10,
      next:"idle"
    }
  }
};

//load run
load("scripts/run.js",true);
