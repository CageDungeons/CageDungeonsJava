//Enable strict mode
"use strict";

//load modules
load("keys");
load("sprite");
load("hud");
load("randElem");
load("mouse");
load("math");
load("id");

//load images
//sprites
load("assets/sprites/player.png",true,false,"img","store");
load("assets/sprites/portal.png",true,false,"img","store");
load("assets/sprites/items.png",true,false,"img","store"),
load("assets/sprites/healingItems.png",true,false,"img","store");
load("assets/sprites/chest.png",true,false,"img","store");
load("assets/sprites/rock.png",true,false,"img","store");
load("assets/sprites/bomb.png",true,false,"img","store");
load("assets/sprites/sword.png",true,false,"img","store");
load("assets/sprites/arrow.png",true,false,"img","store");
load("assets/sprites/lightning.png",true,false,"img","store");
load("assets/sprites/enemies.png",true,false,"img","store");
load("assets/sprites/boss.png",true,false,"img","store");
load("assets/sprites/upperLeft.png",true,false,"img","store");
load("assets/sprites/slime.png",true,false,"img","store");
load("assets/sprites/chestEnemy.png",true,false,"img","store");
//HUD
load("assets/hud/mapIcons.png",true,false,"img","store");
load("assets/hud/areaLabels.png",true,false,"img","store");
load("assets/hud/basicItems.png",true,false,"img","store");
//tilesets
load("assets/tiles/castleTiles.png",true,false,"img","store");
load("assets/tiles/shoreTiles.png",true,false,"img","store");
load("assets/tiles/flatsTiles.png",true,false,"img","store");
load("assets/tiles/poolsTiles.png",true,false,"img","store");
load("assets/tiles/wastesTiles.png",true,false,"img","store");
load("assets/tiles/seaTiles.png",true,false,"img","store");
load("assets/tiles/precipiceTiles.png",true,false,"img","store");
load("assets/tiles/cavernsTiles.png",true,false,"img","store");

//load functions
load("scripts/functions.js",true);

//load templates
load("scripts/templates.js",true);

//load constants
load("scripts/constants.js",true);

/*
Items loades:
  ClassesLoader loads:
    Classes
    Anims loads:
      Run
*/
load("scripts/items.js",true,true);
